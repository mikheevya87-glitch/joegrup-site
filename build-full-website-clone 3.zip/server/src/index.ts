import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import multer from 'multer';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { PrismaClient } from '@prisma/client';
import rateLimit from 'express-rate-limit';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';

/* ═══════════════════════════════════════════════
   CONFIG
   ═══════════════════════════════════════════════ */
const app = express();
const prisma = new PrismaClient();
const PORT = Number(process.env.PORT) || 3001;
const JWT_SECRET = process.env.JWT_SECRET || 'change-me-in-production';
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || 'http://localhost:5173';
const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || '';
const UPLOAD_DIR = path.join(__dirname, '../../uploads');

if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

/* ═══════════════════════════════════════════════
   MIDDLEWARE
   ═══════════════════════════════════════════════ */
app.use(helmet({ crossOriginResourcePolicy: false, contentSecurityPolicy: false }));
app.use(cors({ origin: FRONTEND_ORIGIN, credentials: true }));
app.use(express.json({ limit: '10mb' }));
app.use(cookieParser());
app.use('/uploads', express.static(UPLOAD_DIR, { dotfiles: 'deny', index: false }));

const publicLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 50,
  message: { error: 'Too many requests, try again later' },
});

/* ═══════════════════════════════════════════════
   MULTER — FILE UPLOAD
   ═══════════════════════════════════════════════ */
const storage = multer.diskStorage({
  destination: UPLOAD_DIR,
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const name = crypto.randomBytes(16).toString('hex');
    cb(null, `${name}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: (_req, file, cb) => {
    const allowed = ['.png', '.jpg', '.jpeg', '.webp'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowed.includes(ext) && /^image\/(png|jpe?g|webp)$/.test(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Only PNG, JPG, JPEG, WEBP files allowed'));
    }
  },
});

/* ═══════════════════════════════════════════════
   AUTH MIDDLEWARE
   ═══════════════════════════════════════════════ */
interface AuthRequest extends express.Request {
  userId?: number;
  userEmail?: string;
}

function requireAuth(req: AuthRequest, res: express.Response, next: express.NextFunction): void {
  const token = req.cookies?.token;
  if (!token) { res.status(401).json({ error: 'Unauthorized' }); return; }
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { id: number; email: string };
    req.userId = decoded.id;
    req.userEmail = decoded.email;
    next();
  } catch {
    res.status(401).json({ error: 'Invalid or expired token' });
  }
}

/* ═══════════════════════════════════════════════
   TELEGRAM HELPER
   ═══════════════════════════════════════════════ */
async function sendTelegramMessage(chatId: string, text: string): Promise<boolean> {
  if (!TELEGRAM_BOT_TOKEN || !chatId) return false;
  try {
    const res = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text, parse_mode: 'HTML' }),
    });
    const data = await res.json() as { ok: boolean };
    return data.ok;
  } catch (e) {
    console.error('Telegram send error:', e);
    return false;
  }
}

async function notifyTelegram(type: string, details: Record<string, string>): Promise<void> {
  try {
    const tg = await prisma.telegramSettings.findFirst();
    if (!tg?.enabled || !tg.chatId) return;

    const shouldNotify =
      (type === 'callback' && tg.notifyCallback) ||
      (type === 'order' && tg.notifyOrder) ||
      (type === 'registration' && tg.notifyRegistration);
    if (!shouldNotify) return;

    const icons: Record<string, string> = { callback: '📞', order: '📦', registration: '👤' };
    const labels: Record<string, string> = { callback: 'Обратный звонок', order: 'Новый заказ', registration: 'Регистрация' };
    let text = `${icons[type] || '📬'} <b>${labels[type] || type}</b>\n\n`;
    for (const [k, v] of Object.entries(details)) {
      if (v) text += `${k}: ${v}\n`;
    }
    await sendTelegramMessage(tg.chatId, text);
  } catch (e) {
    console.error('Telegram notify error:', e);
  }
}

/* ═══════════════════════════════════════════════
   ROUTES — AUTH
   ═══════════════════════════════════════════════ */
app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) { res.status(400).json({ error: 'Email and password required' }); return; }

  const user = await prisma.adminUser.findUnique({ where: { email } });
  if (!user || !bcrypt.compareSync(password, user.passwordHash)) {
    res.status(401).json({ error: 'Invalid credentials' });
    return;
  }

  const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '7d' });
  res.cookie('token', token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 7 * 24 * 60 * 60 * 1000,
  });
  res.json({ id: user.id, email: user.email });
});

app.post('/api/auth/logout', (_req, res) => {
  res.clearCookie('token');
  res.json({ ok: true });
});

app.get('/api/auth/me', requireAuth as any, async (req: AuthRequest, res) => {
  const user = await prisma.adminUser.findUnique({ where: { id: req.userId } });
  if (!user) { res.status(404).json({ error: 'User not found' }); return; }
  res.json({ id: user.id, email: user.email });
});

app.put('/api/auth/password', requireAuth as any, async (req: AuthRequest, res) => {
  const { currentPassword, newPassword } = req.body;
  if (!newPassword || newPassword.length < 4) {
    res.status(400).json({ error: 'Password must be at least 4 characters' }); return;
  }
  const user = await prisma.adminUser.findUnique({ where: { id: req.userId } });
  if (!user) { res.status(404).json({ error: 'User not found' }); return; }
  if (currentPassword && !bcrypt.compareSync(currentPassword, user.passwordHash)) {
    res.status(401).json({ error: 'Current password is incorrect' }); return;
  }
  const hash = bcrypt.hashSync(newPassword, 10);
  await prisma.adminUser.update({ where: { id: req.userId }, data: { passwordHash: hash } });
  res.json({ ok: true });
});

/* ═══════════════════════════════════════════════
   ROUTES — SETTINGS
   ═══════════════════════════════════════════════ */
app.get('/api/settings', async (_req, res) => {
  let settings = await prisma.siteSettings.findFirst();
  if (!settings) settings = await prisma.siteSettings.create({ data: {} });

  let telegram = await prisma.telegramSettings.findFirst();
  if (!telegram) telegram = await prisma.telegramSettings.create({ data: {} });

  res.json({
    settings,
    telegram: {
      enabled: telegram.enabled,
      chatId: telegram.chatId,
      notifyRegistration: telegram.notifyRegistration,
      notifyOrder: telegram.notifyOrder,
      notifyCallback: telegram.notifyCallback,
    },
  });
});

app.put('/api/settings', requireAuth as any, async (req, res) => {
  const { settings, telegram } = req.body;
  if (settings) {
    const { id, updatedAt, ...data } = settings;
    await prisma.siteSettings.upsert({
      where: { id: 1 },
      update: data,
      create: { id: 1, ...data },
    });
  }
  if (telegram) {
    const { id, ...data } = telegram;
    await prisma.telegramSettings.upsert({
      where: { id: 1 },
      update: data,
      create: { id: 1, ...data },
    });
  }
  res.json({ ok: true });
});

/* ═══════════════════════════════════════════════
   ROUTES — UPLOAD
   ═══════════════════════════════════════════════ */
app.post('/api/upload', requireAuth as any, (req, res, next) => {
  upload.single('file')(req, res, (err) => {
    if (err instanceof multer.MulterError) {
      res.status(400).json({ error: err.code === 'LIMIT_FILE_SIZE' ? 'File too large (max 5MB)' : err.message });
      return;
    }
    if (err) { res.status(400).json({ error: err.message }); return; }
    if (!req.file) { res.status(400).json({ error: 'No file provided' }); return; }
    const url = `/uploads/${req.file.filename}`;
    res.json({ url });
  });
});

/* ═══════════════════════════════════════════════
   ROUTES — LEADS / ORDERS
   ═══════════════════════════════════════════════ */
app.post('/api/leads', publicLimiter, async (req, res) => {
  const { type = 'callback', name = '', phone = '', email = '', message = '', itemsJson = '', total = 0 } = req.body;

  // Basic input sanitization
  const clean = (s: string) => String(s).trim().slice(0, 2000);

  const lead = await prisma.lead.create({
    data: {
      type: clean(type),
      name: clean(name),
      phone: clean(phone),
      email: clean(email),
      message: clean(message),
      itemsJson: typeof itemsJson === 'string' ? clean(itemsJson) : JSON.stringify(itemsJson),
      total: Number(total) || 0,
    },
  });

  // Telegram notification (async, don't block response)
  notifyTelegram(type, {
    'Имя': name,
    'Телефон': phone,
    'Email': email,
    'Сообщение': message,
    ...(total ? { 'Сумма': `${total} ₽` } : {}),
  });

  res.json(lead);
});

app.get('/api/leads', requireAuth as any, async (req, res) => {
  const { type, status } = req.query;
  const where: any = {};
  if (type) where.type = type;
  if (status) where.status = status;
  const leads = await prisma.lead.findMany({ where, orderBy: { createdAt: 'desc' } });
  res.json(leads);
});

app.patch('/api/leads/:id', requireAuth as any, async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: 'Invalid ID' }); return; }
  const lead = await prisma.lead.update({ where: { id }, data: req.body });
  res.json(lead);
});

app.delete('/api/leads/:id', requireAuth as any, async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: 'Invalid ID' }); return; }
  await prisma.lead.delete({ where: { id } });
  res.json({ ok: true });
});

/* ═══════════════════════════════════════════════
   ROUTES — TELEGRAM TEST
   ═══════════════════════════════════════════════ */
app.post('/api/telegram/test', requireAuth as any, async (_req, res) => {
  if (!TELEGRAM_BOT_TOKEN) {
    res.status(400).json({ error: 'TELEGRAM_BOT_TOKEN not set on server' }); return;
  }
  const tg = await prisma.telegramSettings.findFirst();
  if (!tg?.chatId) {
    res.status(400).json({ error: 'Chat ID not configured' }); return;
  }
  const ok = await sendTelegramMessage(tg.chatId, '✅ <b>CleanDrop</b>\n\nТестовое сообщение — уведомления работают!');
  if (ok) res.json({ ok: true });
  else res.status(500).json({ error: 'Failed to send. Check bot token and chat_id.' });
});

/* ═══════════════════════════════════════════════
   SERVE FRONTEND (production)
   ═══════════════════════════════════════════════ */
const distPath = path.join(__dirname, '../../dist');
if (fs.existsSync(distPath)) {
  app.use(express.static(distPath));
  app.get('*', (_req, res) => {
    res.sendFile(path.join(distPath, 'index.html'));
  });
}

/* ═══════════════════════════════════════════════
   SEED ADMIN & START
   ═══════════════════════════════════════════════ */
async function seed() {
  const email = process.env.ADMIN_EMAIL || 'admin';
  const password = process.env.ADMIN_PASSWORD || 'admin123';
  const existing = await prisma.adminUser.findUnique({ where: { email } });
  if (!existing) {
    const hash = bcrypt.hashSync(password, 10);
    await prisma.adminUser.create({ data: { email, passwordHash: hash } });
    console.log(`✅ Admin user created: ${email}`);
  }
}

seed()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`🚀 CleanDrop server running on http://localhost:${PORT}`);
      console.log(`   Frontend origin: ${FRONTEND_ORIGIN}`);
      console.log(`   Telegram bot: ${TELEGRAM_BOT_TOKEN ? 'configured' : 'not set'}`);
    });
  })
  .catch((e) => {
    console.error('Failed to start:', e);
    process.exit(1);
  });
