// ============================================================
// ТИПЫ
// ============================================================
export interface Product {
  id: string; name: string; description: string; price: number; oldPrice?: number;
  image: string; categoryId: string; badge?: 'new' | 'hit' | 'sale';
  rating: number; volume: string; visible: boolean;
}
export interface Category {
  id: string; name: string; icon: string; description: string; image: string; visible: boolean;
}
export interface User {
  id: string; name: string; email: string; password: string;
  phone: string; city: string; company: string; address: string; role: 'user' | 'admin';
}
export interface CartItem { productId: string; quantity: number; }
export interface Order {
  id: string; userId?: string; customerName: string; company: string;
  phone: string; city: string; address: string; items: { productId: string; quantity: number; productName: string; price: number }[];
  total: number; status: 'new' | 'processing' | 'shipped' | 'completed'; date: string;
}
export interface CallbackReq {
  id: string; name: string; phone: string; comment: string; status: 'new' | 'done'; date: string;
}
export interface BrandLine {
  id: string; name: string; description: string; icon: string; color: string;
}
export interface AboutData {
  title: string; description: string;
  stats: { label: string; value: string }[];
  marketplaces: { name: string; url: string; icon: string; visible: boolean }[];
}
export interface TelegramSettings {
  enabled: boolean;
  chatId: string;
  botToken: string; // For testing only — in production use server .env
  notifyRegistration: boolean;
  notifyOrder: boolean;
  notifyCallback: boolean;
}
export interface SiteSettings {
  siteName: string; logo: string; phone: string; phoneLink: string; email: string;
  address: string; schedule: string; heroTitle: string; heroSubtitle: string; heroBtn1: string; heroBtn2: string;
  heroImage: string;
  heroImageMode: 'right' | 'behind';
  heroImageOpacity: number;  // 0..100
  heroImageScale: number;    // 80..140
  socialVk: string; socialTg: string; socialWa: string;
  theme: 'dark' | 'light';
  phoneVisible: boolean;
  phoneFallbackText: string;
  sectionSpacing: number; // 0.5..1.5 multiplier
  telegram: TelegramSettings;
}

// ============================================================
// НАЧАЛЬНЫЕ ДАННЫЕ
// ============================================================
export const defaultTelegram: TelegramSettings = {
  enabled: false, chatId: '', botToken: '', notifyRegistration: true, notifyOrder: true, notifyCallback: true,
};

export const defaultSettings: SiteSettings = {
  siteName: 'CleanDrop',
  logo: '',
  phone: '+7 (800) 123-45-67',
  phoneLink: 'tel:+78001234567',
  email: 'info@cleandrop.ru',
  address: 'г. Екатеринбург, ул. Промышленная, 12',
  schedule: 'Пн–Пт: 9:00–18:00',
  heroTitle: 'Чистота в каждой капле',
  heroSubtitle: 'Премиальная бытовая химия для тех, кто ценит качество, безопасность и экономичный расход',
  heroBtn1: 'Каталог',
  heroBtn2: 'Заказать звонок',
  heroImage: '',
  heroImageMode: 'right',
  heroImageOpacity: 100,
  heroImageScale: 100,
  socialVk: '', socialTg: '', socialWa: '',
  theme: 'dark',
  phoneVisible: true,
  phoneFallbackText: 'Напишите нам в Telegram',
  sectionSpacing: 1,
  telegram: defaultTelegram,
};

export const defaultAbout: AboutData = {
  title: 'Почему выбирают нас',
  description: 'Мы производим концентрированные средства с заботой о вашем доме и окружающей среде. Каждый продукт проходит строгий контроль качества.',
  stats: [
    { label: 'Лет на рынке', value: '5' },
    { label: 'Довольных клиентов', value: '10 000+' },
    { label: 'Товаров в линейке', value: '50+' },
    { label: 'Маркетплейсов', value: '3' },
  ],
  marketplaces: [
    { name: 'OZON', url: 'https://ozon.ru', icon: '🟦', visible: true },
    { name: 'Wildberries', url: 'https://wildberries.ru', icon: '🟪', visible: true },
    { name: 'Яндекс Маркет', url: 'https://market.yandex.ru', icon: '🟨', visible: true },
  ],
};

export const defaultCategories: Category[] = [
  { id: 'c1', name: 'Стирка', icon: '🧺', description: 'Порошки, гели и кондиционеры для белья', image: '', visible: true },
  { id: 'c2', name: 'Посуда', icon: '🍽️', description: 'Средства для мытья и ополаскивания посуды', image: '', visible: true },
  { id: 'c3', name: 'Уборка', icon: '🧹', description: 'Универсальные чистящие средства', image: '', visible: true },
  { id: 'c4', name: 'Дезинфекция', icon: '🛡️', description: 'Антибактериальные и дезинфицирующие средства', image: '', visible: false },
  { id: 'c5', name: 'Для ванной', icon: '🚿', description: 'Средства для ванной и сантехники', image: '', visible: false },
  { id: 'c6', name: 'Для кухни', icon: '🍳', description: 'Специальные средства для кухни', image: '', visible: false },
  { id: 'c7', name: 'Автохимия', icon: '🚗', description: 'Средства для ухода за автомобилем', image: '', visible: false },
  { id: 'c8', name: 'Ароматизация', icon: '🌸', description: 'Освежители воздуха и ароматизаторы', image: '', visible: false },
];

export const defaultProducts: Product[] = [
  { id: 'p1', name: 'Гель для стирки «Горная свежесть»', description: 'Концентрированный гель для всех типов тканей. Эффективно удаляет загрязнения при 30°C.', price: 450, oldPrice: 590, image: '', categoryId: 'c1', badge: 'hit', rating: 4.8, volume: '1.5 л', visible: true },
  { id: 'p2', name: 'Кондиционер «Альпийские травы»', description: 'Придаёт белью мягкость и свежий аромат горных трав. Антистатический эффект.', price: 320, image: '', categoryId: 'c1', rating: 4.6, volume: '1 л', visible: true },
  { id: 'p3', name: 'Порошок «Кристалл»', description: 'Универсальный стиральный порошок для белого и цветного белья.', price: 380, image: '', categoryId: 'c1', badge: 'new', rating: 4.7, volume: '2 кг', visible: true },
  { id: 'p4', name: 'Средство для посуды «Лимон»', description: 'Концентрированное средство с натуральным экстрактом лимона. Без фосфатов.', price: 190, image: '', categoryId: 'c2', badge: 'hit', rating: 4.9, volume: '500 мл', visible: true },
  { id: 'p5', name: 'Гель для посуды «Алоэ Вера»', description: 'Бережный уход за кожей рук с экстрактом алоэ. Густая формула.', price: 220, image: '', categoryId: 'c2', rating: 4.5, volume: '750 мл', visible: true },
  { id: 'p6', name: 'Ополаскиватель для ПММ', description: 'Придаёт посуде блеск, предотвращает образование разводов.', price: 340, image: '', categoryId: 'c2', badge: 'new', rating: 4.4, volume: '500 мл', visible: true },
  { id: 'p7', name: 'Универсальное средство «Всё в одном»', description: 'Для мытья полов, кафеля, пластика и стекла. Без разводов.', price: 280, image: '', categoryId: 'c3', rating: 4.7, volume: '1 л', visible: true },
  { id: 'p8', name: 'Средство для стёкол «Кристалл»', description: 'Профессиональная формула для зеркальной чистоты без разводов.', price: 210, oldPrice: 290, image: '', categoryId: 'c3', badge: 'sale', rating: 4.8, volume: '500 мл', visible: true },
  { id: 'p9', name: 'Крем чистящий «Актив»', description: 'Деликатная чистка без царапин. Для раковин, ванн и плит.', price: 170, image: '', categoryId: 'c3', rating: 4.3, volume: '500 мл', visible: true },
];

export const defaultBrandLines: BrandLine[] = [
  { id: 'bl1', name: 'Premium Pro', description: 'Линейка для профессионального клининга', icon: '👑', color: '#B7925C' },
  { id: 'bl2', name: 'EcoClean', description: 'Экологичная линейка без фосфатов и хлора', icon: '🌿', color: '#5C9E6F' },
  { id: 'bl3', name: 'Family Care', description: 'Гипоаллергенная серия для всей семьи', icon: '👨‍👩‍👧‍👦', color: '#7EC8E3' },
];

export const defaultAdminUser: User = {
  id: 'admin1', name: 'Администратор', email: 'admin', password: 'admin123',
  phone: '', city: '', company: '', address: '', role: 'admin',
};
