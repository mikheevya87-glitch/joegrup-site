/* ═══════════════════════════════════════════════════════════
   API Layer — calls backend when available, returns null otherwise.
   Frontend falls back to localStorage when API returns null.
   Set VITE_API_URL env var to enable backend integration.
   ═══════════════════════════════════════════════════════════ */

/// <reference types="vite/client" />
const BASE: string = (import.meta.env?.VITE_API_URL as string) || '';

async function request<T = any>(method: string, path: string, body?: unknown): Promise<T | null> {
  if (!BASE) return null;
  try {
    const opts: RequestInit = {
      method,
      credentials: 'include',
      headers: body instanceof FormData ? {} : { 'Content-Type': 'application/json' },
      body: body instanceof FormData ? body : body ? JSON.stringify(body) : undefined,
    };
    const res = await fetch(`${BASE}${path}`, opts);
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: res.statusText }));
      throw new Error(err.error || res.statusText);
    }
    return await res.json();
  } catch (e) {
    console.warn(`API ${method} ${path} failed:`, e);
    return null;
  }
}

export const api = {
  // Auth
  login: (email: string, password: string) =>
    request('POST', '/api/auth/login', { email, password }),
  logout: () => request('POST', '/api/auth/logout'),
  me: () => request('GET', '/api/auth/me'),
  changePassword: (currentPassword: string, newPassword: string) =>
    request('PUT', '/api/auth/password', { currentPassword, newPassword }),

  // Settings
  getSettings: () => request('GET', '/api/settings'),
  updateSettings: (data: { settings?: any; telegram?: any }) =>
    request('PUT', '/api/settings', data),

  // Leads
  createLead: (data: any) => request('POST', '/api/leads', data),
  getLeads: (params?: { type?: string; status?: string }) => {
    const qs = params ? '?' + new URLSearchParams(params as any).toString() : '';
    return request('GET', `/api/leads${qs}`);
  },
  updateLead: (id: string | number, data: any) =>
    request('PATCH', `/api/leads/${id}`, data),
  deleteLead: (id: string | number) =>
    request('DELETE', `/api/leads/${id}`),

  // Upload
  uploadFile: async (file: File): Promise<string | null> => {
    if (!BASE) return null;
    const fd = new FormData();
    fd.append('file', file);
    const result = await request<{ url: string }>('POST', '/api/upload', fd);
    return result?.url ? `${BASE}${result.url}` : null;
  },

  // Telegram
  testTelegram: () => request('POST', '/api/telegram/test'),

  // Check if backend is available
  isAvailable: async (): Promise<boolean> => {
    if (!BASE) return false;
    try {
      const res = await fetch(`${BASE}/api/settings`, { credentials: 'include' });
      return res.ok;
    } catch {
      return false;
    }
  },
};

/* Upload helper — tries API first, falls back to base64 data URL */
export async function uploadImage(file: File): Promise<string> {
  // Validate
  const validTypes = ['image/png', 'image/jpeg', 'image/webp'];
  if (!validTypes.includes(file.type)) throw new Error('Только PNG, JPG, WEBP');
  if (file.size > 5 * 1024 * 1024) throw new Error('Максимум 5MB');

  // Try API upload
  const url = await api.uploadFile(file);
  if (url) return url;

  // Fallback: base64 data URL (works without backend)
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}
