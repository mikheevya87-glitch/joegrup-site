import { useStore } from '../contexts/AppContext';

interface Props { onCallback: () => void; }

const whyUs = [
  { icon: '💧', title: 'Концентрат', desc: 'Высокая концентрация активных веществ — расход в 3 раза меньше обычных средств' },
  { icon: '🛡️', title: 'Безопасность', desc: 'Без фосфатов, хлора и агрессивных ПАВ. Безопасно для детей и питомцев' },
  { icon: '✅', title: 'Контроль качества', desc: 'Каждая партия проходит лабораторный контроль и сертификацию' },
  { icon: '🌿', title: 'Экологичность', desc: 'Биоразлагаемые формулы, перерабатываемая упаковка' },
];

const steps = [
  { num: '01', title: 'Выберите средство', desc: 'Подберите продукт из каталога под вашу задачу' },
  { num: '02', title: 'Дозируйте', desc: 'Следуйте инструкции — концентрат экономит расход' },
  { num: '03', title: 'Наслаждайтесь', desc: 'Идеальная чистота и свежесть гарантированы' },
];

export default function About({ onCallback }: Props) {
  const { about } = useStore();

  return (
    <>
      {/* ───── WHY US ───── */}
      <section className="py-14 md:py-20 relative">
        <hr className="divider" />
        <div className="max-w-[1200px] mx-auto px-5 lg:px-8 pt-14 md:pt-20">
          <div className="text-center mb-10">
            <p className="section-label">Преимущества</p>
            <h2 className="section-title">{about.title}</h2>
            <p className="section-desc mx-auto">{about.description}</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {whyUs.map((item, i) => (
              <div key={i} className="card p-7 group">
                <div className="w-12 h-12 rounded-[var(--radius-s)] flex items-center justify-center text-[24px] mb-5 bg-[rgba(198,169,107,0.06)] border border-[rgba(198,169,107,0.08)] group-hover:bg-[rgba(198,169,107,0.1)] transition-colors">
                  {item.icon}
                </div>
                <h3 className="font-bold text-[15px] mb-2 text-[var(--text)]" style={{ fontFamily: 'Manrope' }}>{item.title}</h3>
                <p className="text-[12px] text-[var(--text3)] leading-[1.7]">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ───── ABOUT COMPANY ───── */}
      <section id="about" className="py-14 md:py-20 relative">
        <hr className="divider" />
        <div className="max-w-[1200px] mx-auto px-5 lg:px-8 pt-14 md:pt-20">
          <div className="max-w-3xl">
            <p className="section-label">О компании</p>
            <h2 className="section-title">Качество, которому доверяют</h2>
            <p className="text-[14px] text-[var(--text2)] leading-[1.8] mb-8">{about.description}</p>

            {/* Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
              {about.stats.map((stat, i) => (
                <div key={i} className="bg-[var(--surface)] rounded-[var(--radius)] border border-[var(--border)] p-5">
                  <div className="text-[24px] font-bold tracking-[-0.02em]" style={{ fontFamily: 'Manrope', color: 'var(--gold)' }}>{stat.value}</div>
                  <div className="text-[11px] text-[var(--text3)] mt-1 leading-snug">{stat.label}</div>
                </div>
              ))}
            </div>

            {/* Marketplaces */}
            {about.marketplaces.filter(m => m.visible).length > 0 && (
              <div>
                <p className="text-[12px] text-[var(--text3)] mb-3 uppercase tracking-[0.06em] font-medium" style={{ fontFamily: 'Manrope' }}>Мы на маркетплейсах</p>
                <div className="flex flex-wrap gap-2">
                  {about.marketplaces.filter(m => m.visible).map((mp, i) => (
                    <a key={i} href={mp.url} target="_blank" rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2.5 rounded-[var(--radius-s)] bg-[var(--surface)] border border-[var(--border)] text-[13px] font-medium text-[var(--text2)] hover:border-[var(--gold-b)] hover:text-[var(--gold)] transition-all">
                      <span>{mp.icon}</span> {mp.name}
                    </a>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* ───── HOW TO USE ───── */}
      <section className="py-14 md:py-20">
        <hr className="divider" />
        <div className="max-w-[1200px] mx-auto px-5 lg:px-8 pt-14 md:pt-20">
          <div className="text-center mb-10">
            <p className="section-label">Инструкция</p>
            <h2 className="section-title">Как использовать</h2>
            <p className="section-desc mx-auto">Три простых шага к идеальной чистоте</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {steps.map((step, i) => (
              <div key={i} className="card p-8 text-center relative">
                <div className="text-[42px] font-extrabold mb-5 leading-none" style={{ fontFamily: 'Manrope', color: 'var(--gold)', opacity: 0.08 }}>
                  {step.num}
                </div>
                <h3 className="font-bold text-[16px] mb-2 text-[var(--text)]" style={{ fontFamily: 'Manrope' }}>{step.title}</h3>
                <p className="text-[13px] text-[var(--text3)] leading-relaxed">{step.desc}</p>
                {i < 2 && (
                  <div className="hidden md:flex absolute top-1/2 -right-4 w-8 items-center justify-center text-[var(--text3)] opacity-20 z-10">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><polyline points="9 6 15 12 9 18"/></svg>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* ───── CTA ───── */}
          <div className="mt-16 relative overflow-hidden rounded-[var(--radius-xl)] border border-[var(--border)] bg-[var(--surface)]">
            <div className="absolute -top-16 -right-16 w-48 h-48 rounded-full opacity-[0.06]" style={{ background: 'radial-gradient(circle, var(--gold), transparent 70%)' }} />
            <div className="relative z-10 py-14 px-8 text-center">
              <p className="section-label">Начните сейчас</p>
              <h2 className="text-[clamp(22px,4vw,34px)] font-bold mb-4 tracking-[-0.02em]" style={{ fontFamily: 'Manrope' }}>Готовы попробовать?</h2>
              <p className="text-[14px] text-[var(--text2)] mb-8 max-w-md mx-auto">Оставьте заявку и мы подберём оптимальное решение для ваших задач</p>
              <button onClick={onCallback} className="btn-gold">
                Заказать звонок
              </button>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
