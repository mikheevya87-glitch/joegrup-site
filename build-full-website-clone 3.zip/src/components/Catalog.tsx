import { useState, useEffect } from 'react';
import { useStore } from '../contexts/AppContext';

interface Props { activeCat: string | null; }

export default function Catalog({ activeCat }: Props) {
  const { products, categories, addToCart, currentUser } = useStore();
  const visCats = categories.filter(c => c.visible);
  const [selCat, setSelCat] = useState<string | null>(null);
  const [added, setAdded] = useState<string | null>(null);

  useEffect(() => { if (activeCat) setSelCat(activeCat); }, [activeCat]);

  const filtered = products.filter(p => p.visible && (selCat ? p.categoryId === selCat : visCats.some(c => c.id === p.categoryId)));
  const isAdmin = currentUser?.role === 'admin';

  const handleAdd = (pid: string) => {
    addToCart(pid);
    setAdded(pid);
    setTimeout(() => setAdded(null), 1200);
  };

  const count = (cid: string) => products.filter(p => p.categoryId === cid && p.visible).length;
  const plural = (n: number) => {
    const m = n % 10, d = n % 100;
    if (d >= 11 && d <= 14) return 'товаров';
    if (m === 1) return 'товар'; if (m >= 2 && m <= 4) return 'товара'; return 'товаров';
  };

  return (
    <section id="catalog" className="py-24 md:py-32 relative">
      <div className="max-w-[1200px] mx-auto px-5 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-14">
          <p className="section-label">Продукция</p>
          <h2 className="section-title">Каталог продукции</h2>
          <p className="section-desc mx-auto">Выберите категорию и найдите подходящее средство</p>
        </div>

        {/* Category pills */}
        <div className="flex gap-2 mb-10 overflow-x-auto pb-2 no-scrollbar">
          <button onClick={() => setSelCat(null)}
            className={`flex-shrink-0 px-5 py-2.5 rounded-[var(--radius-s)] text-[13px] font-semibold transition-all border cursor-pointer ${
              !selCat
                ? 'bg-[var(--gold)] text-[#0B0B0D] border-[var(--gold)]'
                : 'bg-transparent text-[var(--text3)] border-[var(--border)] hover:border-[var(--gold-b)] hover:text-[var(--gold)]'
            }`} style={{ fontFamily: 'Manrope' }}>
            Все
          </button>
          {visCats.map(cat => (
            <button key={cat.id} onClick={() => setSelCat(cat.id)}
              className={`flex-shrink-0 px-5 py-2.5 rounded-[var(--radius-s)] text-[13px] font-semibold transition-all border cursor-pointer whitespace-nowrap ${
                selCat === cat.id
                  ? 'bg-[var(--gold)] text-[#0B0B0D] border-[var(--gold)]'
                  : 'bg-transparent text-[var(--text3)] border-[var(--border)] hover:border-[var(--gold-b)] hover:text-[var(--gold)]'
              }`} style={{ fontFamily: 'Manrope' }}>
              {cat.icon} {cat.name}
              <span className="ml-1.5 text-[11px] opacity-60">{count(cat.id)}</span>
            </button>
          ))}
        </div>

        {/* Category cards (no selection) */}
        {!selCat && visCats.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-14">
            {visCats.map(cat => (
              <button key={cat.id} onClick={() => setSelCat(cat.id)}
                className="card p-6 text-left cursor-pointer group">
                {cat.image ? (
                  <img src={cat.image} alt="" className="w-12 h-12 rounded-[var(--radius-s)] mb-4 object-cover" />
                ) : (
                  <div className="text-[28px] mb-4 w-12 h-12 flex items-center justify-center">{cat.icon}</div>
                )}
                <h3 className="font-bold text-[15px] mb-1.5 text-[var(--text)] group-hover:text-[var(--gold)] transition-colors" style={{ fontFamily: 'Manrope' }}>
                  {cat.name}
                </h3>
                <p className="text-[12px] text-[var(--text3)] mb-3 leading-relaxed line-clamp-2">{cat.description}</p>
                <span className="text-[12px] text-[var(--gold)] font-semibold" style={{ fontFamily: 'Manrope' }}>
                  {count(cat.id)} {plural(count(cat.id))}
                  <span className="ml-1 inline-block group-hover:translate-x-1 transition-transform">→</span>
                </span>
              </button>
            ))}
          </div>
        )}

        {/* Back button when category selected */}
        {selCat && (
          <button onClick={() => setSelCat(null)}
            className="mb-8 text-[13px] text-[var(--text3)] hover:text-[var(--gold)] transition-colors cursor-pointer bg-transparent border-none flex items-center gap-2"
            style={{ fontFamily: 'Manrope' }}>
            <span>←</span> Все категории
          </button>
        )}

        {/* Product grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map(product => {
            const cat = categories.find(c => c.id === product.categoryId);
            return (
              <div key={product.id} className="card group">
                {/* Image area */}
                <div className="relative h-52 flex items-center justify-center overflow-hidden"
                  style={{ background: 'linear-gradient(160deg, var(--surface2), var(--surface3))' }}>
                  {product.image ? (
                    <img src={product.image} alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  ) : (
                    <span className="text-[48px] opacity-20 group-hover:scale-110 transition-transform duration-500">{cat?.icon || '📦'}</span>
                  )}

                  {/* Badges */}
                  <div className="absolute top-3 left-3 flex gap-1.5">
                    {product.badge && (
                      <span className={`badge ${product.badge === 'new' ? 'badge-new' : product.badge === 'hit' ? 'badge-hit' : 'badge-sale'}`}>
                        {product.badge === 'new' ? 'Новинка' : product.badge === 'hit' ? 'Хит' : 'Скидка'}
                      </span>
                    )}
                  </div>
                  {isAdmin && !product.visible && (
                    <span className="absolute top-3 right-3 badge bg-red-500/10 text-red-400 border border-red-500/20">Скрыт</span>
                  )}
                </div>

                {/* Content */}
                <div className="p-5">
                  <div className="flex items-center gap-2 mb-2.5">
                    <span className="text-[10px] font-medium text-[var(--text3)] bg-[rgba(255,255,255,0.03)] border border-[var(--border)] px-2.5 py-1 rounded-[8px]" style={{ fontFamily: 'Manrope' }}>
                      {cat?.name}
                    </span>
                    <span className="text-[10px] text-[var(--text3)]">{product.volume}</span>
                  </div>

                  <h3 className="font-bold text-[14px] mb-2 leading-snug text-[var(--text)]" style={{ fontFamily: 'Manrope' }}>
                    {product.name}
                  </h3>
                  <p className="text-[12px] text-[var(--text3)] mb-4 line-clamp-2 leading-relaxed">{product.description}</p>

                  {/* Rating */}
                  <div className="flex items-center gap-1 mb-4">
                    {[1,2,3,4,5].map(s => (
                      <svg key={s} width="12" height="12" viewBox="0 0 16 16" fill={s <= Math.round(product.rating) ? 'var(--gold)' : 'var(--surface3)'}>
                        <path d="M8 1l2.2 4.5 5 .7-3.6 3.5.9 5L8 12.4 3.5 14.7l.9-5L.8 6.2l5-.7L8 1z"/>
                      </svg>
                    ))}
                    <span className="text-[10px] text-[var(--text3)] ml-1">{product.rating}</span>
                  </div>

                  {/* Price + Cart */}
                  <div className="flex items-center justify-between pt-4 border-t border-[var(--border)]">
                    <div className="flex items-baseline gap-2">
                      <span className="text-[20px] font-bold tracking-[-0.02em]" style={{ fontFamily: 'Manrope' }}>{product.price} ₽</span>
                      {product.oldPrice && (
                        <span className="text-[13px] text-[var(--text3)] line-through">{product.oldPrice} ₽</span>
                      )}
                    </div>
                    <button onClick={() => handleAdd(product.id)}
                      className={`w-10 h-10 rounded-[var(--radius-s)] flex items-center justify-center border transition-all duration-300 cursor-pointer ${
                        added === product.id
                          ? 'bg-green-500/20 border-green-500/30 text-green-400 scale-110'
                          : 'border-[var(--border2)] bg-transparent text-[var(--gold)] hover:bg-[var(--gold)] hover:text-[#0B0B0D] hover:border-[var(--gold)]'
                      }`}>
                      {added === product.id ? (
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                      ) : (
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-20">
            <div className="text-[40px] mb-4 opacity-15">📦</div>
            <p className="text-[14px] text-[var(--text3)]">В этой категории пока нет товаров</p>
          </div>
        )}
      </div>
    </section>
  );
}
