import { useState } from 'react';
import { useStore } from '../contexts/AppContext';

interface Props { open: boolean; onClose: () => void; }

export default function LoginModal({ open, onClose }: Props) {
  const { login, register } = useStore();
  const [tab, setTab] = useState<'login' | 'register'>('login');
  const [err, setErr] = useState('');

  // Separate state for each field to avoid re-render issues
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('');
  const [company, setCompany] = useState('');
  const [address, setAddress] = useState('');

  if (!open) return null;

  const resetForm = () => {
    setEmail(''); setPassword(''); setName('');
    setPhone(''); setCity(''); setCompany(''); setAddress('');
    setErr('');
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault(); setErr('');
    const r = login(email, password);
    if (r) setErr(r); else { onClose(); resetForm(); }
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault(); setErr('');
    if (!name || !email || !password) { setErr('Заполните обязательные поля'); return; }
    const r = register({ name, email, password, phone, city, company, address });
    if (r) setErr(r); else { onClose(); resetForm(); }
  };

  const labelCls = "block text-[11px] font-medium text-[var(--text3)] mb-1.5 uppercase tracking-[0.06em]";

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/75 backdrop-blur-md" />
      <div className="relative w-full max-w-[420px] bg-[var(--surface)] rounded-[var(--radius-l)] border border-[var(--border)] shadow-2xl overflow-hidden" onClick={e => e.stopPropagation()}>
        {/* Tabs */}
        <div className="flex">
          {(['login', 'register'] as const).map(t => (
            <button key={t} onClick={() => { setTab(t); setErr(''); }}
              className={`flex-1 py-4 text-[13px] font-semibold transition-all cursor-pointer border-b-2 bg-transparent ${
                tab === t
                  ? 'text-[var(--gold)] border-[var(--gold)]'
                  : 'text-[var(--text3)] border-transparent hover:text-[var(--text2)]'
              }`}
              style={{ fontFamily: 'Manrope' }}>
              {t === 'login' ? 'Вход' : 'Регистрация'}
            </button>
          ))}
        </div>

        <form onSubmit={tab === 'login' ? handleLogin : handleRegister} className="p-6 flex flex-col gap-3.5">
          {tab === 'register' && (
            <>
              <div>
                <label className={labelCls}>Имя / Компания *</label>
                <input className="admin-input" value={name} onChange={e => setName(e.target.value)} placeholder="ИП Иванов" />
              </div>
              <div>
                <label className={labelCls}>Телефон</label>
                <input className="admin-input" value={phone} onChange={e => setPhone(e.target.value)} placeholder="+7 (999) 123-45-67" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelCls}>Город</label>
                  <input className="admin-input" value={city} onChange={e => setCity(e.target.value)} placeholder="Екатеринбург" />
                </div>
                <div>
                  <label className={labelCls}>Компания</label>
                  <input className="admin-input" value={company} onChange={e => setCompany(e.target.value)} placeholder="ООО «Компания»" />
                </div>
              </div>
              <div>
                <label className={labelCls}>Адрес доставки</label>
                <input className="admin-input" value={address} onChange={e => setAddress(e.target.value)} placeholder="ул. Латвийская, 1" />
              </div>
            </>
          )}
          <div>
            <label className={labelCls}>{tab === 'login' ? 'Логин' : 'Email *'}</label>
            <input className="admin-input" value={email} onChange={e => setEmail(e.target.value)} placeholder={tab === 'login' ? 'Логин' : 'email@example.com'} />
          </div>
          <div>
            <label className={labelCls}>Пароль *</label>
            <input className="admin-input" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" />
          </div>
          {err && <p className="text-red-400 text-[13px] bg-red-500/5 border border-red-500/10 rounded-[10px] px-3 py-2">{err}</p>}
          <button type="submit" className="btn-gold w-full py-3.5 mt-1">
            {tab === 'login' ? 'Войти' : 'Зарегистрироваться'}
          </button>
        </form>

        <button onClick={onClose} className="absolute top-3.5 right-3.5 w-8 h-8 rounded-[10px] flex items-center justify-center text-[var(--text3)] hover:text-[var(--text)] hover:bg-[rgba(255,255,255,0.04)] bg-transparent border-none cursor-pointer transition-colors">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
      </div>
    </div>
  );
}
