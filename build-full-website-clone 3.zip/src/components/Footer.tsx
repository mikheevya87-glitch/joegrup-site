import { useStore } from '../contexts/AppContext';

interface Props { onCallback: () => void; }

export default function Footer({ onCallback }: Props) {
  const { settings } = useStore();

  return (
    <footer className="relative border-t border-[var(--border)]">
      <div className="max-w-[1200px] mx-auto px-5 lg:px-8 py-12 md:py-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
          {/* Brand + Socials */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              {settings.logo ? (
                <img src={settings.logo} alt="" className="h-8 w-8 rounded-[8px] object-cover" />
              ) : (
                <div className="w-8 h-8 rounded-[8px] flex items-center justify-center" style={{ background: 'linear-gradient(135deg, var(--gold), var(--gold-l))' }}>
                  <svg width="14" height="18" viewBox="0 0 18 22" fill="none">
                    <path d="M9 0C9 0 0 9.5 0 14.5C0 18.64 4.03 22 9 22C13.97 22 18 18.64 18 14.5C18 9.5 9 0 9 0Z" fill="#0B0B0D" opacity="0.7"/>
                  </svg>
                </div>
              )}
              <span className="text-[16px] font-bold tracking-[-0.02em]" style={{ fontFamily: 'Manrope' }}>{settings.siteName}</span>
            </div>
            <div className="flex gap-2 mt-3">
              {settings.socialVk && (
                <a href={settings.socialVk} target="_blank" rel="noopener noreferrer"
                  className="w-9 h-9 rounded-[10px] border border-[var(--border)] flex items-center justify-center text-[var(--text3)] hover:text-[var(--gold)] hover:border-[var(--gold-b)] transition-all text-[12px]">VK</a>
              )}
              {settings.socialTg && (
                <a href={settings.socialTg} target="_blank" rel="noopener noreferrer"
                  className="w-9 h-9 rounded-[10px] border border-[var(--border)] flex items-center justify-center text-[var(--text3)] hover:text-[var(--gold)] hover:border-[var(--gold-b)] transition-all text-[12px]">TG</a>
              )}
              {settings.socialWa && (
                <a href={settings.socialWa} target="_blank" rel="noopener noreferrer"
                  className="w-9 h-9 rounded-[10px] border border-[var(--border)] flex items-center justify-center text-[var(--text3)] hover:text-[var(--gold)] hover:border-[var(--gold-b)] transition-all text-[12px]">WA</a>
              )}
            </div>
          </div>

          {/* Contacts */}
          <div>
            <h4 className="text-[11px] font-bold uppercase tracking-[0.1em] text-[var(--text3)] mb-4" style={{ fontFamily: 'Manrope' }}>Контакты</h4>
            <div className="flex flex-col gap-2.5">
              {settings.phoneVisible ? (
                <a href={settings.phoneLink} className="text-[14px] font-semibold text-[var(--text)] hover:text-[var(--gold)] transition-colors" style={{ fontFamily: 'Manrope' }}>
                  {settings.phone}
                </a>
              ) : settings.socialTg ? (
                <a href={settings.socialTg} target="_blank" rel="noopener noreferrer" className="text-[14px] font-semibold text-[var(--text)] hover:text-[var(--gold)] transition-colors">
                  {settings.phoneFallbackText || 'Напишите нам'}
                </a>
              ) : null}
              <a href={`mailto:${settings.email}`} className="text-[13px] text-[var(--text2)] hover:text-[var(--gold)] transition-colors">{settings.email}</a>
              <p className="text-[12px] text-[var(--text3)]">{settings.address}</p>
              <p className="text-[12px] text-[var(--text3)]">{settings.schedule}</p>
            </div>
          </div>

          {/* CTA */}
          <div>
            <h4 className="text-[11px] font-bold uppercase tracking-[0.1em] text-[var(--text3)] mb-4" style={{ fontFamily: 'Manrope' }}>Покупателям</h4>
            <div className="flex flex-wrap gap-2 mb-5">
              {['Сертификаты', 'Доставка', 'Оптовикам'].map(label => (
                <button key={label} onClick={onCallback}
                  className="text-[13px] text-[var(--text2)] hover:text-[var(--gold)] transition-colors bg-transparent border border-[var(--border)] hover:border-[var(--gold-b)] rounded-[var(--radius-s)] px-3.5 py-2 cursor-pointer">
                  {label}
                </button>
              ))}
            </div>
            <button onClick={onCallback} className="btn-gold btn-sm w-full">Заказать звонок</button>
          </div>
        </div>

        <div className="mt-10 pt-5 border-t border-[var(--border)] flex flex-col sm:flex-row justify-between items-center gap-2">
          <p className="text-[11px] text-[var(--text3)]">© {new Date().getFullYear()} {settings.siteName}. Все права защищены.</p>
        </div>
      </div>
    </footer>
  );
}
