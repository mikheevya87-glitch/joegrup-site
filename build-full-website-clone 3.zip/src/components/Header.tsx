import { useState, useEffect } from 'react';
import { useStore } from '../contexts/AppContext';

interface Props { onLogin: () => void; onCart: () => void; onCallback: () => void; }

export default function Header({ onLogin, onCart, onCallback }: Props) {
  const { settings, currentUser, logout, cartCount, toggleTheme } = useStore();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', h, { passive: true });
    return () => window.removeEventListener('scroll', h);
  }, []);

  const isDark = settings.theme !== 'light';

  return (
    <header
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-500"
      style={{
        background: scrolled ? 'var(--header-bg)' : 'transparent',
        backdropFilter: scrolled ? 'blur(20px)' : 'none',
        WebkitBackdropFilter: scrolled ? 'blur(20px)' : 'none',
        boxShadow: scrolled ? '0 1px 0 var(--border)' : 'none',
      }}
    >
      <div className="max-w-[1200px] mx-auto px-5 lg:px-8 h-[72px] flex items-center justify-between">
        {/* Logo */}
        <a href="#" className="flex items-center gap-3 group" onClick={e => { e.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' }); }}>
          {settings.logo ? (
            <img src={settings.logo} alt="" className="h-9 w-9 rounded-[10px] object-cover" />
          ) : (
            <div className="w-9 h-9 rounded-[10px] flex items-center justify-center relative overflow-hidden"
              style={{ background: 'linear-gradient(135deg, var(--gold), var(--gold-l))' }}>
              <svg width="18" height="22" viewBox="0 0 18 22" fill="none">
                <path d="M9 0C9 0 0 9.5 0 14.5C0 18.64 4.03 22 9 22C13.97 22 18 18.64 18 14.5C18 9.5 9 0 9 0Z" fill="#0B0B0D" opacity="0.7"/>
                <path d="M9 3C9 3 3 10 3 13.5C3 16.54 5.69 19 9 19C12.31 19 15 16.54 15 13.5C15 10 9 3 9 3Z" fill="#0B0B0D" opacity="0.3"/>
              </svg>
            </div>
          )}
          <span className="text-[17px] font-bold tracking-[-0.02em] text-[var(--text)] group-hover:text-[var(--gold)] transition-colors" style={{ fontFamily: 'Manrope' }}>
            {settings.siteName}
          </span>
        </a>

        {/* Right */}
        <div className="flex items-center gap-2">
          {/* Phone — only if phoneVisible */}
          {settings.phoneVisible ? (
            <a href={settings.phoneLink} className="hidden lg:block text-[14px] font-semibold text-[var(--text)] hover:text-[var(--gold)] transition-colors mr-2" style={{ fontFamily: 'Manrope' }}>
              {settings.phone}
            </a>
          ) : settings.phoneFallbackText && settings.socialTg ? (
            <a href={settings.socialTg} target="_blank" rel="noopener noreferrer" className="hidden lg:flex items-center gap-1.5 text-[13px] text-[var(--text2)] hover:text-[var(--gold)] transition-colors mr-2">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69.01-.03.01-.14-.07-.2-.08-.06-.19-.04-.27-.02-.12.03-1.99 1.27-5.62 3.72-.53.36-1.01.54-1.44.53-.47-.01-1.38-.27-2.06-.49-.83-.27-1.49-.42-1.43-.88.03-.24.37-.49 1.02-.75 3.98-1.73 6.64-2.88 7.97-3.44 3.8-1.58 4.59-1.86 5.1-1.87.11 0 .37.03.53.17.14.12.18.28.2.45-.01.06.01.24 0 .38z"/></svg>
              {settings.phoneFallbackText}
            </a>
          ) : null}

          <button onClick={onCallback} className="hidden sm:flex btn-gold btn-sm">
            Заказать звонок
          </button>

          {/* Theme toggle */}
          <button onClick={toggleTheme} className="theme-toggle" title={isDark ? 'Светлая тема' : 'Тёмная тема'}>
            {isDark ? (
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
                <circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>
              </svg>
            ) : (
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
                <path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"/>
              </svg>
            )}
          </button>

          {/* Cart */}
          <button onClick={onCart}
            className="relative w-10 h-10 rounded-[var(--radius-s)] flex items-center justify-center border border-[var(--border)] bg-transparent text-[var(--text2)] hover:text-[var(--text)] hover:border-[var(--border3)] transition-all cursor-pointer">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/>
            </svg>
            {cartCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 min-w-[18px] h-[18px] rounded-full text-[10px] font-bold flex items-center justify-center px-1"
                style={{ background: 'linear-gradient(135deg, var(--gold), var(--gold-l))', color: '#0B0B0D' }}>
                {cartCount}
              </span>
            )}
          </button>

          {/* User */}
          {currentUser ? (
            <div className="flex items-center gap-2">
              <span className="hidden lg:block text-[12px] text-[var(--text3)] max-w-[100px] truncate">{currentUser.name}</span>
              <button onClick={logout}
                className="w-10 h-10 rounded-[var(--radius-s)] flex items-center justify-center border border-[var(--border)] bg-transparent text-[var(--text3)] hover:text-red-400 hover:border-red-500/30 transition-all cursor-pointer"
                title="Выйти">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>
                </svg>
              </button>
            </div>
          ) : (
            <button onClick={onLogin}
              className="w-10 h-10 rounded-[var(--radius-s)] flex items-center justify-center border border-[var(--border)] bg-transparent text-[var(--text3)] hover:text-[var(--gold)] hover:border-[var(--gold-b)] transition-all cursor-pointer"
              title="Войти">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/>
              </svg>
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
