import { useStore } from '../contexts/AppContext';

export default function BrandLines() {
  const { brandLines } = useStore();
  if (brandLines.length === 0) return null;

  return (
    <section id="brands" className="py-14 md:py-20">
      <hr className="divider" />
      <div className="max-w-[1200px] mx-auto px-5 lg:px-8 pt-14 md:pt-20">
        <div className="text-center mb-10">
          <p className="section-label">Бренды</p>
          <h2 className="section-title">Наши линейки</h2>
          <p className="section-desc mx-auto">Каждая линейка создана для решения конкретных задач</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {brandLines.map(bl => (
            <div key={bl.id} className="card p-7 group">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 rounded-[var(--radius-s)] flex items-center justify-center text-[22px]"
                  style={{ background: `${bl.color}12`, border: `1px solid ${bl.color}20` }}>
                  {bl.icon}
                </div>
                <h3 className="font-bold text-[16px] transition-colors" style={{ fontFamily: 'Manrope', color: bl.color }}>
                  {bl.name}
                </h3>
              </div>
              <p className="text-[13px] text-[var(--text3)] leading-[1.7]">{bl.description}</p>
              <div className="mt-5 h-[1px] w-0 group-hover:w-full transition-all duration-500" style={{ background: `linear-gradient(90deg, ${bl.color}, transparent)` }} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
