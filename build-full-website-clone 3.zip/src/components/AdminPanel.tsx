import { useState, useRef } from 'react';
import { useStore, uid } from '../contexts/AppContext';
import { uploadImage } from '../api';
import type { Product, Category, BrandLine } from '../data';

interface Props { open: boolean; onClose: () => void; }

const tabs = ['📞 Заявки','📦 Заказы','👥 Клиенты','🛒 Товары','📁 Категории','🏢 О компании','🏷️ Линейки','⚙️ Настройки'];

/* ─── Stable input components (defined OUTSIDE to prevent re-mount) ─── */
function AdminInput({ label, value, onChange, type = 'text', ph = '' }: {
  label: string; value: string | number | undefined; onChange: (v: string) => void; type?: string; ph?: string;
}) {
  return (
    <div>
      <label className="text-[10px] text-[var(--text3)] mb-1 block uppercase tracking-wider">{label}</label>
      <input className="admin-input" type={type} value={value ?? ''} onChange={e => onChange(e.target.value)} placeholder={ph} />
    </div>
  );
}

function AdminTextarea({ label, value, onChange, rows = 3 }: {
  label: string; value: string; onChange: (v: string) => void; rows?: number;
}) {
  return (
    <div>
      <label className="text-[10px] text-[var(--text3)] mb-1 block uppercase tracking-wider">{label}</label>
      <textarea className="admin-input" rows={rows} value={value} onChange={e => onChange(e.target.value)} />
    </div>
  );
}

/* ─── Toggle Switch ─── */
function Toggle({ active, onChange, label }: { active: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <div className="toggle-wrap">
      <div className={`toggle ${active ? 'active' : ''}`} onClick={() => onChange(!active)} />
      <span className="text-[13px] text-[var(--text2)]">{label}</span>
    </div>
  );
}

/* ─── File Upload Field ─── */
function FileUploadField({ label, value, onChange, hint }: {
  label: string; value: string; onChange: (v: string) => void; hint?: string;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [dragover, setDragover] = useState(false);
  const [error, setError] = useState('');

  const handleFile = async (file: File) => {
    setError('');
    setUploading(true);
    try {
      const url = await uploadImage(file);
      onChange(url);
    } catch (e: any) {
      setError(e.message || 'Ошибка загрузки');
    }
    setUploading(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault(); setDragover(false);
    if (e.dataTransfer.files?.[0]) handleFile(e.dataTransfer.files[0]);
  };

  return (
    <div>
      <label className="text-[10px] text-[var(--text3)] mb-1 block uppercase tracking-wider">{label}</label>
      <div className="flex gap-2 mb-2">
        <input className="admin-input flex-1" value={value} onChange={e => onChange(e.target.value)} placeholder="URL изображения или загрузите файл" />
        <input ref={fileRef} type="file" accept="image/png,image/jpeg,image/webp" className="hidden"
          onChange={e => { if (e.target.files?.[0]) handleFile(e.target.files[0]); e.target.value = ''; }} />
        <button onClick={() => fileRef.current?.click()} disabled={uploading}
          className="admin-btn bg-[var(--surface3)] text-[var(--text2)] hover:text-[var(--gold)] flex items-center gap-1.5 whitespace-nowrap">
          {uploading ? '⏳' : '📁'} {uploading ? 'Загрузка...' : 'Файл'}
        </button>
      </div>
      {/* Drop zone */}
      <div
        className={`upload-zone ${dragover ? 'dragover' : ''}`}
        onDragOver={e => { e.preventDefault(); setDragover(true); }}
        onDragLeave={() => setDragover(false)}
        onDrop={handleDrop}
        onClick={() => fileRef.current?.click()}
      >
        <p className="text-[12px] text-[var(--text3)]">
          {uploading ? '⏳ Загрузка...' : '📁 Перетащите изображение сюда или нажмите'}
        </p>
        <p className="text-[10px] text-[var(--text3)] mt-1 opacity-60">PNG, JPG, WEBP • до 5MB</p>
      </div>
      {error && <p className="text-[11px] text-red-400 mt-1">{error}</p>}
      {value && (
        <div className="mt-2 flex items-center gap-3 p-2 bg-[var(--surface3)] rounded-[10px]">
          <img src={value} alt="" className="w-14 h-14 object-cover rounded-lg" onError={e => (e.currentTarget.style.display = 'none')} />
          <button onClick={() => onChange('')} className="admin-btn bg-red-500/10 text-red-400 text-[10px]">✕ Убрать</button>
        </div>
      )}
      {hint && <p className="text-[10px] text-[var(--text3)] mt-1 opacity-60">{hint}</p>}
    </div>
  );
}

export default function AdminPanel({ open, onClose }: Props) {
  const store = useStore();
  const [tab, setTab] = useState(0);
  const [editProd, setEditProd] = useState<Partial<Product> | null>(null);
  const [editCat, setEditCat] = useState<Partial<Category> | null>(null);
  const [editBL, setEditBL] = useState<Partial<BrandLine> | null>(null);
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [passMsg, setPassMsg] = useState('');
  const [tgTestMsg, setTgTestMsg] = useState('');

  if (!open) return null;
  const { callbacks, orders, users, products, categories, about, settings, brandLines, currentUser } = store;
  const newCb = callbacks.filter(c => c.status === 'new').length;
  const newOrd = orders.filter(o => o.status === 'new').length;

  const saveProd = () => {
    if (!editProd?.name) return;
    if (editProd.id && products.find(p => p.id === editProd.id)) {
      store.updateProduct(editProd.id, editProd);
    } else {
      store.addProduct({ id: uid(), name: editProd.name || '', description: editProd.description || '', price: editProd.price || 0, image: editProd.image || '', categoryId: editProd.categoryId || categories[0]?.id || '', rating: editProd.rating || 4.5, volume: editProd.volume || '', visible: editProd.visible !== false, badge: editProd.badge as Product['badge'], oldPrice: editProd.oldPrice });
    }
    setEditProd(null);
  };

  const saveCat = () => {
    if (!editCat?.name) return;
    if (editCat.id && categories.find(c => c.id === editCat.id)) {
      store.updateCategory(editCat.id, editCat);
    } else {
      store.addCategory({ id: uid(), name: editCat.name || '', icon: editCat.icon || '📦', description: editCat.description || '', image: editCat.image || '', visible: editCat.visible !== false });
    }
    setEditCat(null);
  };

  const saveBL = () => {
    if (!editBL?.name) return;
    if (editBL.id && brandLines.find(b => b.id === editBL.id)) {
      store.updateBrandLine(editBL.id, editBL);
    } else {
      store.addBrandLine({ id: uid(), name: editBL.name || '', description: editBL.description || '', icon: editBL.icon || '📦', color: editBL.color || '#B7925C' });
    }
    setEditBL(null);
  };

  const handleChangePassword = () => {
    if (!newPass) { setPassMsg('Введите новый пароль'); return; }
    if (newPass.length < 4) { setPassMsg('Минимум 4 символа'); return; }
    if (newPass !== confirmPass) { setPassMsg('Пароли не совпадают'); return; }
    if (currentUser) {
      store.updateUserPassword(currentUser.id, newPass);
      setNewPass(''); setConfirmPass('');
      setPassMsg('✅ Пароль успешно изменён!');
      setTimeout(() => setPassMsg(''), 3000);
    }
  };

  const handleTelegramTest = async () => {
    setTgTestMsg('⏳ Отправка...');
    const result = await store.notifyTelegram('test');
    if (result.ok) setTgTestMsg('✅ Тестовое сообщение отправлено!');
    else setTgTestMsg(`❌ ${result.error || 'Ошибка отправки'}`);
    setTimeout(() => setTgTestMsg(''), 6000);
  };

  const statusLabel = (s: string) => {
    const m: Record<string, string> = { new: '🟡 Новый', processing: '🔵 В работе', shipped: '📦 Отправлен', completed: '✅ Выполнен', done: '✅ Перезвонили' };
    return m[s] || s;
  };

  return (
    <div className="fixed inset-0 z-[300] flex" onClick={onClose}>
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" />
      <div className="relative ml-auto w-full max-w-3xl bg-[var(--surface)] h-full overflow-y-auto shadow-2xl border-l border-[var(--border)]" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="sticky top-0 z-10 bg-[var(--surface)] border-b border-[var(--border)] px-5 py-4 flex items-center justify-between">
          <h2 className="text-lg font-bold" style={{ fontFamily: 'Manrope' }}>⚙️ Админ-панель</h2>
          <div className="flex items-center gap-3">
            <button onClick={() => { if (confirm('Сбросить все данные?')) store.resetAll(); }} className="admin-btn bg-red-500/20 text-red-400 hover:bg-red-500/30">Сброс</button>
            <button onClick={onClose} className="text-[var(--text3)] hover:text-[var(--text)] bg-transparent border-none cursor-pointer text-xl">✕</button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex overflow-x-auto border-b border-[var(--border)] px-5 gap-1 no-scrollbar">
          {tabs.map((t, i) => (
            <button key={i} onClick={() => setTab(i)}
              className={`flex-shrink-0 px-3 py-3 text-xs font-medium transition-colors border-b-2 cursor-pointer bg-transparent relative ${tab === i ? 'text-[var(--gold)] border-[var(--gold)]' : 'text-[var(--text3)] border-transparent hover:text-[var(--text)]'}`}>
              {t}
              {i === 0 && newCb > 0 && <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-red-500 text-white text-[8px] flex items-center justify-center">{newCb}</span>}
              {i === 1 && newOrd > 0 && <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-red-500 text-white text-[8px] flex items-center justify-center">{newOrd}</span>}
            </button>
          ))}
        </div>

        <div className="p-5">
          {/* TAB 0: Callbacks */}
          {tab === 0 && (
            <div className="space-y-3">
              {callbacks.length === 0 && <p className="text-[var(--text3)] text-sm text-center py-8">Заявок пока нет</p>}
              {[...callbacks].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(cb => (
                <div key={cb.id} className="bg-[var(--surface2)] rounded-xl border border-[var(--border)] p-4">
                  <div className="flex justify-between items-start mb-2">
                    <div><span className="font-semibold text-sm">{cb.name}</span><span className="text-xs text-[var(--text3)] ml-2">{new Date(cb.date).toLocaleString('ru')}</span></div>
                    <span className="text-xs">{statusLabel(cb.status)}</span>
                  </div>
                  <p className="text-sm text-[var(--gold)] mb-1">{cb.phone}</p>
                  {cb.comment && <p className="text-xs text-[var(--text3)]">{cb.comment}</p>}
                  <div className="flex gap-2 mt-3">
                    {cb.status === 'new' ? (
                      <button onClick={() => store.updateCallbackStatus(cb.id, 'done')} className="admin-btn bg-green-500/20 text-green-400 hover:bg-green-500/30">✅ Перезвонили</button>
                    ) : (
                      <button onClick={() => store.updateCallbackStatus(cb.id, 'new')} className="admin-btn bg-[var(--surface3)] text-[var(--text3)]">↩️ Вернуть</button>
                    )}
                    <button onClick={() => store.deleteCallback(cb.id)} className="admin-btn bg-red-500/10 text-red-400 hover:bg-red-500/20">🗑️</button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* TAB 1: Orders */}
          {tab === 1 && (
            <div className="space-y-3">
              {orders.length === 0 && <p className="text-[var(--text3)] text-sm text-center py-8">Заказов пока нет</p>}
              {[...orders].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(ord => (
                <div key={ord.id} className="bg-[var(--surface2)] rounded-xl border border-[var(--border)] p-4">
                  <div className="flex justify-between items-start mb-2">
                    <div><span className="font-semibold text-sm">{ord.customerName}</span>{ord.company && <span className="text-xs text-[var(--text3)] ml-2">({ord.company})</span>}</div>
                    <span className="text-xs">{statusLabel(ord.status)}</span>
                  </div>
                  <p className="text-sm text-[var(--gold)]">📞 {ord.phone}</p>
                  <p className="text-xs text-[var(--text3)]">📍 {ord.city}, {ord.address}</p>
                  <div className="mt-2 bg-[var(--bg)] rounded-lg p-3">
                    {ord.items.map((it, i) => (
                      <div key={i} className="flex justify-between text-xs py-1">
                        <span>{it.productName} × {it.quantity}</span>
                        <span className="text-[var(--gold)]">{it.price * it.quantity} ₽</span>
                      </div>
                    ))}
                    <div className="border-t border-[var(--border)] mt-2 pt-2 flex justify-between text-sm font-bold">
                      <span>Итого:</span><span className="text-[var(--gold)]">{ord.total} ₽</span>
                    </div>
                  </div>
                  <div className="flex gap-2 mt-3 flex-wrap">
                    {(['new', 'processing', 'shipped', 'completed'] as const).map(s => (
                      <button key={s} onClick={() => store.updateOrderStatus(ord.id, s)}
                        className={`admin-btn ${ord.status === s ? 'bg-[var(--gold)] text-[#0B0B0D]' : 'bg-[var(--surface3)] text-[var(--text3)]'}`}>
                        {statusLabel(s)}
                      </button>
                    ))}
                    <button onClick={() => store.deleteOrder(ord.id)} className="admin-btn bg-red-500/10 text-red-400">🗑️</button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* TAB 2: Clients */}
          {tab === 2 && (
            <div className="space-y-3">
              {users.filter(u => u.role === 'user').length === 0 && <p className="text-[var(--text3)] text-sm text-center py-8">Клиентов пока нет</p>}
              {users.filter(u => u.role === 'user').map(user => {
                const userOrders = orders.filter(o => o.userId === user.id);
                const totalSum = userOrders.reduce((s, o) => s + o.total, 0);
                return (
                  <div key={user.id} className="bg-[var(--surface2)] rounded-xl border border-[var(--border)] p-4">
                    <div className="flex justify-between items-start">
                      <div><p className="font-semibold text-sm">{user.name}</p>{user.company && <p className="text-xs text-[var(--text3)]">{user.company}</p>}</div>
                      <span className="text-xs text-[var(--gold)] font-medium">Заказов: {userOrders.length} ({totalSum} ₽)</span>
                    </div>
                    <div className="grid grid-cols-2 gap-2 mt-2 text-xs text-[var(--text3)]">
                      <p>📞 {user.phone || '—'}</p><p>📧 {user.email}</p>
                      <p>📍 {user.city || '—'}</p><p>🏠 {user.address || '—'}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* TAB 3: Products */}
          {tab === 3 && (
            <div>
              <button onClick={() => setEditProd({ visible: true, rating: 4.5, categoryId: categories[0]?.id })} className="admin-btn bg-[var(--gold)] text-[#0B0B0D] mb-4">+ Добавить товар</button>
              {editProd && (
                <div className="bg-[var(--surface2)] rounded-xl border border-[var(--gold)]/30 p-4 mb-4 space-y-3">
                  <h3 className="text-sm font-bold" style={{ fontFamily: 'Manrope' }}>{editProd.id ? 'Редактировать' : 'Новый товар'}</h3>
                  <AdminInput label="Название" value={editProd.name} onChange={v => setEditProd(p => ({ ...p!, name: v }))} />
                  <AdminInput label="Описание" value={editProd.description} onChange={v => setEditProd(p => ({ ...p!, description: v }))} />
                  <div className="grid grid-cols-2 gap-3">
                    <AdminInput label="Цена" value={editProd.price} type="number" onChange={v => setEditProd(p => ({ ...p!, price: +v }))} />
                    <AdminInput label="Старая цена" value={editProd.oldPrice} type="number" onChange={v => setEditProd(p => ({ ...p!, oldPrice: +v || undefined }))} />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <AdminInput label="Объём" value={editProd.volume} onChange={v => setEditProd(p => ({ ...p!, volume: v }))} ph="1 л" />
                    <AdminInput label="Рейтинг" value={editProd.rating} type="number" onChange={v => setEditProd(p => ({ ...p!, rating: +v }))} />
                  </div>
                  <FileUploadField label="Фото товара" value={editProd.image || ''} onChange={v => setEditProd(p => ({ ...p!, image: v }))} hint="Рекомендуемый размер: 600×600px" />
                  <div>
                    <label className="text-[10px] text-[var(--text3)] mb-1 block uppercase tracking-wider">Категория</label>
                    <select className="admin-input" value={editProd.categoryId || ''} onChange={e => setEditProd(p => ({ ...p!, categoryId: e.target.value }))}>
                      {categories.map(c => <option key={c.id} value={c.id}>{c.icon} {c.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] text-[var(--text3)] mb-1 block uppercase tracking-wider">Бейдж</label>
                    <select className="admin-input" value={editProd.badge || ''} onChange={e => setEditProd(p => ({ ...p!, badge: (e.target.value || undefined) as Product['badge'] }))}>
                      <option value="">Нет</option><option value="new">NEW</option><option value="hit">HIT</option><option value="sale">SALE</option>
                    </select>
                  </div>
                  <Toggle active={editProd.visible !== false} onChange={v => setEditProd(p => ({ ...p!, visible: v }))} label="Показать на витрине" />
                  <div className="flex gap-2">
                    <button onClick={saveProd} className="admin-btn bg-[var(--gold)] text-[#0B0B0D]">Сохранить</button>
                    <button onClick={() => setEditProd(null)} className="admin-btn bg-[var(--surface3)] text-[var(--text3)]">Отмена</button>
                  </div>
                </div>
              )}
              <div className="space-y-2">
                {products.map(p => {
                  const cat = categories.find(c => c.id === p.categoryId);
                  return (
                    <div key={p.id} className={`bg-[var(--surface2)] rounded-xl border p-3 flex items-center gap-3 ${p.visible ? 'border-[var(--border)]' : 'border-red-500/20 opacity-60'}`}>
                      <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-[var(--surface3)] flex-shrink-0 text-lg overflow-hidden">
                        {p.image ? <img src={p.image} alt="" className="w-full h-full rounded-lg object-cover" /> : cat?.icon || '📦'}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{p.name}</p>
                        <p className="text-[10px] text-[var(--text3)]">{cat?.name} · {p.price} ₽ · {p.volume}</p>
                      </div>
                      <div className="flex gap-1 flex-shrink-0">
                        <button onClick={() => store.toggleProductVis(p.id)} className={`admin-btn text-[10px] ${p.visible ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>{p.visible ? '👁️' : '🚫'}</button>
                        <button onClick={() => setEditProd({ ...p })} className="admin-btn bg-[var(--surface3)] text-[var(--text3)] text-[10px]">✏️</button>
                        <button onClick={() => store.deleteProduct(p.id)} className="admin-btn bg-red-500/10 text-red-400 text-[10px]">🗑️</button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 4: Categories */}
          {tab === 4 && (
            <div>
              <button onClick={() => setEditCat({ visible: true })} className="admin-btn bg-[var(--gold)] text-[#0B0B0D] mb-4">+ Добавить категорию</button>
              {editCat && (
                <div className="bg-[var(--surface2)] rounded-xl border border-[var(--gold)]/30 p-4 mb-4 space-y-3">
                  <AdminInput label="Название" value={editCat.name} onChange={v => setEditCat(p => ({ ...p!, name: v }))} />
                  <AdminInput label="Иконка (emoji)" value={editCat.icon} onChange={v => setEditCat(p => ({ ...p!, icon: v }))} ph="🧺" />
                  <AdminInput label="Описание" value={editCat.description} onChange={v => setEditCat(p => ({ ...p!, description: v }))} />
                  <FileUploadField label="Фото категории" value={editCat.image || ''} onChange={v => setEditCat(p => ({ ...p!, image: v }))} />
                  <Toggle active={editCat.visible !== false} onChange={v => setEditCat(p => ({ ...p!, visible: v }))} label="Показать на витрине" />
                  <div className="flex gap-2">
                    <button onClick={saveCat} className="admin-btn bg-[var(--gold)] text-[#0B0B0D]">Сохранить</button>
                    <button onClick={() => setEditCat(null)} className="admin-btn bg-[var(--surface3)] text-[var(--text3)]">Отмена</button>
                  </div>
                </div>
              )}
              <div className="space-y-2">
                {categories.map(cat => (
                  <div key={cat.id} className={`bg-[var(--surface2)] rounded-xl border p-3 flex items-center gap-3 ${cat.visible ? 'border-[var(--border)]' : 'border-red-500/20 opacity-60'}`}>
                    <span className="text-2xl">{cat.icon}</span>
                    <div className="flex-1"><p className="text-sm font-medium">{cat.name}</p><p className="text-[10px] text-[var(--text3)]">{products.filter(p => p.categoryId === cat.id).length} товаров</p></div>
                    <div className="flex gap-1">
                      <button onClick={() => store.toggleCategoryVis(cat.id)} className={`admin-btn text-[10px] ${cat.visible ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>{cat.visible ? '👁️' : '🚫'}</button>
                      <button onClick={() => setEditCat({ ...cat })} className="admin-btn bg-[var(--surface3)] text-[var(--text3)] text-[10px]">✏️</button>
                      <button onClick={() => { if (confirm('Удалить категорию и все товары?')) store.deleteCategory(cat.id); }} className="admin-btn bg-red-500/10 text-red-400 text-[10px]">🗑️</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: About */}
          {tab === 5 && (
            <div className="space-y-6">
              <div className="space-y-3">
                <h3 className="text-sm font-bold" style={{ fontFamily: 'Manrope' }}>Тексты</h3>
                <AdminInput label="Заголовок" value={about.title} onChange={v => store.updateAbout({ title: v })} />
                <AdminTextarea label="Описание" value={about.description} onChange={v => store.updateAbout({ description: v })} />
              </div>
              <div className="space-y-3">
                <h3 className="text-sm font-bold" style={{ fontFamily: 'Manrope' }}>Статистика</h3>
                {about.stats.map((stat, i) => (
                  <div key={i} className="grid grid-cols-2 gap-3">
                    <AdminInput label={`Метка ${i + 1}`} value={stat.label} onChange={v => { const s = [...about.stats]; s[i] = { ...s[i], label: v }; store.updateAbout({ stats: s }); }} />
                    <AdminInput label={`Значение ${i + 1}`} value={stat.value} onChange={v => { const s = [...about.stats]; s[i] = { ...s[i], value: v }; store.updateAbout({ stats: s }); }} />
                  </div>
                ))}
                <button onClick={() => store.updateAbout({ stats: [...about.stats, { label: 'Новое', value: '0' }] })} className="admin-btn bg-[var(--surface3)] text-[var(--text3)]">+ Добавить</button>
              </div>
              <div className="space-y-3">
                <h3 className="text-sm font-bold" style={{ fontFamily: 'Manrope' }}>Маркетплейсы</h3>
                {about.marketplaces.map((mp, i) => (
                  <div key={i} className="bg-[var(--surface2)] rounded-xl border border-[var(--border)] p-3 space-y-2">
                    <div className="grid grid-cols-3 gap-2">
                      <AdminInput label="Название" value={mp.name} onChange={v => { const m = [...about.marketplaces]; m[i] = { ...m[i], name: v }; store.updateAbout({ marketplaces: m }); }} />
                      <AdminInput label="Иконка" value={mp.icon} onChange={v => { const m = [...about.marketplaces]; m[i] = { ...m[i], icon: v }; store.updateAbout({ marketplaces: m }); }} />
                      <AdminInput label="URL" value={mp.url} onChange={v => { const m = [...about.marketplaces]; m[i] = { ...m[i], url: v }; store.updateAbout({ marketplaces: m }); }} />
                    </div>
                    <div className="flex items-center gap-3">
                      <Toggle active={mp.visible} onChange={v => { const m = [...about.marketplaces]; m[i] = { ...m[i], visible: v }; store.updateAbout({ marketplaces: m }); }} label="Показать" />
                      <button onClick={() => { const m = about.marketplaces.filter((_, j) => j !== i); store.updateAbout({ marketplaces: m }); }} className="admin-btn bg-red-500/10 text-red-400 text-[10px]">🗑️</button>
                    </div>
                  </div>
                ))}
                <button onClick={() => store.updateAbout({ marketplaces: [...about.marketplaces, { name: 'Новый', url: '', icon: '🔗', visible: true }] })} className="admin-btn bg-[var(--surface3)] text-[var(--text3)]">+ Добавить</button>
              </div>
            </div>
          )}

          {/* TAB 6: Brand Lines */}
          {tab === 6 && (
            <div>
              <button onClick={() => setEditBL({})} className="admin-btn bg-[var(--gold)] text-[#0B0B0D] mb-4">+ Добавить линейку</button>
              {editBL && (
                <div className="bg-[var(--surface2)] rounded-xl border border-[var(--gold)]/30 p-4 mb-4 space-y-3">
                  <AdminInput label="Название" value={editBL.name} onChange={v => setEditBL(p => ({ ...p!, name: v }))} />
                  <AdminInput label="Описание" value={editBL.description} onChange={v => setEditBL(p => ({ ...p!, description: v }))} />
                  <AdminInput label="Иконка" value={editBL.icon} onChange={v => setEditBL(p => ({ ...p!, icon: v }))} ph="👑" />
                  <AdminInput label="Цвет" value={editBL.color} onChange={v => setEditBL(p => ({ ...p!, color: v }))} ph="#B7925C" />
                  <div className="flex gap-2">
                    <button onClick={saveBL} className="admin-btn bg-[var(--gold)] text-[#0B0B0D]">Сохранить</button>
                    <button onClick={() => setEditBL(null)} className="admin-btn bg-[var(--surface3)] text-[var(--text3)]">Отмена</button>
                  </div>
                </div>
              )}
              <div className="space-y-2">
                {brandLines.map(bl => (
                  <div key={bl.id} className="bg-[var(--surface2)] rounded-xl border border-[var(--border)] p-3 flex items-center gap-3">
                    <span className="text-2xl">{bl.icon}</span>
                    <div className="flex-1"><p className="font-medium text-sm" style={{ color: bl.color }}>{bl.name}</p><p className="text-[10px] text-[var(--text3)]">{bl.description}</p></div>
                    <button onClick={() => setEditBL({ ...bl })} className="admin-btn bg-[var(--surface3)] text-[var(--text3)] text-[10px]">✏️</button>
                    <button onClick={() => store.deleteBrandLine(bl.id)} className="admin-btn bg-red-500/10 text-red-400 text-[10px]">🗑️</button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 7: Settings */}
          {tab === 7 && (
            <div className="space-y-6">
              {/* ─── General ─── */}
              <div className="space-y-3">
                <h3 className="text-sm font-bold flex items-center gap-2" style={{ fontFamily: 'Manrope' }}>🏪 Основные</h3>
                <AdminInput label="Название сайта" value={settings.siteName} onChange={v => store.updateSettings({ siteName: v })} />
                <FileUploadField label="Логотип" value={settings.logo} onChange={v => store.updateSettings({ logo: v })} hint="Рекомендуемый размер: 128×128px, PNG" />
              </div>

              <hr className="border-[var(--border)]" />

              {/* ─── Theme ─── */}
              <div className="space-y-3">
                <h3 className="text-sm font-bold flex items-center gap-2" style={{ fontFamily: 'Manrope' }}>🎨 Тема оформления</h3>
                <div className="flex gap-3">
                  <button onClick={() => store.updateSettings({ theme: 'dark' })}
                    className={`flex-1 p-4 rounded-[var(--radius)] border-2 transition-all cursor-pointer ${settings.theme === 'dark' ? 'border-[var(--gold)] bg-[#0B0B0D]' : 'border-[var(--border)] bg-[var(--surface2)]'}`}>
                    <div className="w-full h-8 rounded-lg mb-2" style={{ background: '#0B0B0D', border: '1px solid rgba(255,255,255,0.1)' }} />
                    <p className="text-[12px] font-medium text-center">🌙 Тёмная</p>
                  </button>
                  <button onClick={() => store.updateSettings({ theme: 'light' })}
                    className={`flex-1 p-4 rounded-[var(--radius)] border-2 transition-all cursor-pointer ${settings.theme === 'light' ? 'border-[var(--gold)] bg-[#FAFAF8]' : 'border-[var(--border)] bg-[var(--surface2)]'}`}>
                    <div className="w-full h-8 rounded-lg mb-2" style={{ background: '#FAFAF8', border: '1px solid rgba(0,0,0,0.1)' }} />
                    <p className="text-[12px] font-medium text-center">☀️ Светлая</p>
                  </button>
                </div>
              </div>

              <hr className="border-[var(--border)]" />

              {/* ─── Layout Density ─── */}
              <div className="space-y-3">
                <h3 className="text-sm font-bold flex items-center gap-2" style={{ fontFamily: 'Manrope' }}>📐 Плотность контента</h3>
                <div>
                  <label className="text-[10px] text-[var(--text3)] mb-1 block uppercase tracking-wider">
                    Расстояние между блоками: {Math.round((settings.sectionSpacing ?? 1) * 100)}%
                  </label>
                  <input type="range" min="0.4" max="1.6" step="0.05" value={settings.sectionSpacing ?? 1}
                    onChange={e => store.updateSettings({ sectionSpacing: +e.target.value })}
                    className="w-full accent-[var(--gold)]" />
                  <div className="flex justify-between text-[10px] text-[var(--text3)] mt-1">
                    <span>Компактно</span><span>Стандарт</span><span>Просторно</span>
                  </div>
                </div>
              </div>

              <hr className="border-[var(--border)]" />

              {/* ─── Phone ─── */}
              <div className="space-y-3">
                <h3 className="text-sm font-bold flex items-center gap-2" style={{ fontFamily: 'Manrope' }}>📞 Телефон</h3>
                <AdminInput label="Номер телефона" value={settings.phone} onChange={v => store.updateSettings({ phone: v })} />
                <AdminInput label="Ссылка (tel:)" value={settings.phoneLink} onChange={v => store.updateSettings({ phoneLink: v })} ph="tel:+7..." />
                <Toggle active={settings.phoneVisible} onChange={v => store.updateSettings({ phoneVisible: v })} label="Показывать телефон на сайте" />
                {!settings.phoneVisible && (
                  <AdminInput label="Текст замены (вместо телефона)" value={settings.phoneFallbackText} onChange={v => store.updateSettings({ phoneFallbackText: v })} ph="Напишите нам в Telegram" />
                )}
              </div>

              <hr className="border-[var(--border)]" />

              {/* ─── Contacts ─── */}
              <div className="space-y-3">
                <h3 className="text-sm font-bold flex items-center gap-2" style={{ fontFamily: 'Manrope' }}>📬 Контакты</h3>
                <AdminInput label="Email" value={settings.email} onChange={v => store.updateSettings({ email: v })} />
                <AdminInput label="Адрес" value={settings.address} onChange={v => store.updateSettings({ address: v })} />
                <AdminInput label="Расписание" value={settings.schedule} onChange={v => store.updateSettings({ schedule: v })} />
              </div>

              <hr className="border-[var(--border)]" />

              {/* ─── Banner ─── */}
              <div className="space-y-3">
                <h3 className="text-sm font-bold flex items-center gap-2" style={{ fontFamily: 'Manrope' }}>🖼️ Баннер</h3>
                <AdminInput label="Заголовок" value={settings.heroTitle} onChange={v => store.updateSettings({ heroTitle: v })} />
                <AdminInput label="Подзаголовок" value={settings.heroSubtitle} onChange={v => store.updateSettings({ heroSubtitle: v })} />
                <FileUploadField label="Изображение героя (вместо капли)" value={settings.heroImage} onChange={v => store.updateSettings({ heroImage: v })} hint="Рекомендуемый размер: 600×800px, PNG с прозрачным фоном" />
                {settings.heroImage && (
                  <div className="space-y-3 bg-[var(--bg)] rounded-xl p-3 border border-[var(--border)]">
                    <div>
                      <label className="text-[10px] text-[var(--text3)] mb-1 block uppercase tracking-wider">Режим отображения</label>
                      <div className="flex gap-2">
                        <button onClick={() => store.updateSettings({ heroImageMode: 'right' })}
                          className={`flex-1 p-3 rounded-xl text-[12px] font-medium cursor-pointer border transition-all ${settings.heroImageMode === 'right' ? 'border-[var(--gold)] text-[var(--gold)] bg-[rgba(198,169,107,0.06)]' : 'border-[var(--border)] text-[var(--text3)] bg-transparent'}`}>
                          ➡️ Справа от текста
                        </button>
                        <button onClick={() => store.updateSettings({ heroImageMode: 'behind' })}
                          className={`flex-1 p-3 rounded-xl text-[12px] font-medium cursor-pointer border transition-all ${settings.heroImageMode === 'behind' ? 'border-[var(--gold)] text-[var(--gold)] bg-[rgba(198,169,107,0.06)]' : 'border-[var(--border)] text-[var(--text3)] bg-transparent'}`}>
                          🖼️ За текстом (фон)
                        </button>
                      </div>
                    </div>
                    <div>
                      <label className="text-[10px] text-[var(--text3)] mb-1 block uppercase tracking-wider">Прозрачность: {settings.heroImageOpacity ?? 100}%</label>
                      <input type="range" min="10" max="100" step="5" value={settings.heroImageOpacity ?? 100}
                        onChange={e => store.updateSettings({ heroImageOpacity: +e.target.value })}
                        className="w-full accent-[var(--gold)]" />
                    </div>
                    <div>
                      <label className="text-[10px] text-[var(--text3)] mb-1 block uppercase tracking-wider">Масштаб: {settings.heroImageScale ?? 100}%</label>
                      <input type="range" min="60" max="150" step="5" value={settings.heroImageScale ?? 100}
                        onChange={e => store.updateSettings({ heroImageScale: +e.target.value })}
                        className="w-full accent-[var(--gold)]" />
                    </div>
                  </div>
                )}
                <AdminInput label="Кнопка «Каталог»" value={settings.heroBtn1} onChange={v => store.updateSettings({ heroBtn1: v })} />
              </div>

              <hr className="border-[var(--border)]" />

              {/* ─── Socials ─── */}
              <div className="space-y-3">
                <h3 className="text-sm font-bold flex items-center gap-2" style={{ fontFamily: 'Manrope' }}>🌐 Соцсети</h3>
                <AdminInput label="VK" value={settings.socialVk} onChange={v => store.updateSettings({ socialVk: v })} ph="https://vk.com/..." />
                <AdminInput label="Telegram" value={settings.socialTg} onChange={v => store.updateSettings({ socialTg: v })} ph="https://t.me/..." />
                <AdminInput label="WhatsApp" value={settings.socialWa} onChange={v => store.updateSettings({ socialWa: v })} ph="https://wa.me/..." />
              </div>

              <hr className="border-[var(--border)]" />

              {/* ─── Telegram Notifications ─── */}
              <div className="space-y-3">
                <h3 className="text-sm font-bold flex items-center gap-2" style={{ fontFamily: 'Manrope' }}>🤖 Уведомления в Telegram</h3>
                <Toggle active={settings.telegram.enabled} onChange={v => store.updateTelegram({ enabled: v })} label="Включить уведомления" />
                {settings.telegram.enabled && (
                  <>
                    <AdminInput label="Chat ID" value={settings.telegram.chatId} onChange={v => store.updateTelegram({ chatId: v })} ph="Получить через @userinfobot в Telegram" />
                    <div className="bg-[var(--bg)] rounded-xl p-3 border border-[var(--border)]">
                      <p className="text-[10px] text-[var(--text3)] mb-2 uppercase tracking-wider">⚠️ Bot Token (только для тестирования)</p>
                      <AdminInput label="" value={settings.telegram.botToken} onChange={v => store.updateTelegram({ botToken: v })} ph="123456:ABC-DEF..." />
                      <p className="text-[10px] text-[var(--text3)] mt-1.5 leading-relaxed opacity-70">
                        В продакшене токен хранится на сервере в .env файле. Сейчас для тестирования уведомления отправляются напрямую.
                      </p>
                    </div>
                    <Toggle active={settings.telegram.notifyCallback} onChange={v => store.updateTelegram({ notifyCallback: v })} label="Заявки на звонок" />
                    <Toggle active={settings.telegram.notifyOrder} onChange={v => store.updateTelegram({ notifyOrder: v })} label="Новые заказы" />
                    <Toggle active={settings.telegram.notifyRegistration} onChange={v => store.updateTelegram({ notifyRegistration: v })} label="Регистрации" />
                    <button onClick={handleTelegramTest} className="admin-btn bg-blue-500/20 text-blue-400 hover:bg-blue-500/30 w-full flex items-center justify-center gap-2">
                      📨 Отправить тестовое сообщение
                    </button>
                    {tgTestMsg && (
                      <p className={`text-[12px] px-3 py-2 rounded-lg ${tgTestMsg.includes('✅') ? 'text-green-400 bg-green-500/10' : tgTestMsg.includes('⏳') ? 'text-blue-400 bg-blue-500/10' : 'text-red-400 bg-red-500/10'}`}>
                        {tgTestMsg}
                      </p>
                    )}
                    <div className="bg-[var(--bg)] rounded-xl p-3 border border-[var(--border)]">
                      <p className="text-[10px] text-[var(--text3)] leading-relaxed">
                        <b>Как настроить:</b><br/>
                        1. Откройте @BotFather в Telegram → /newbot → скопируйте токен<br/>
                        2. Откройте @userinfobot → скопируйте ваш Chat ID<br/>
                        3. Вставьте оба значения выше → нажмите «Отправить тест»
                      </p>
                    </div>
                  </>
                )}
              </div>

              <hr className="border-[var(--border)]" />

              {/* ─── Password ─── */}
              <div className="space-y-3">
                <h3 className="text-sm font-bold flex items-center gap-2" style={{ fontFamily: 'Manrope' }}>🔐 Смена пароля</h3>
                <p className="text-[11px] text-[var(--text3)]">Текущий логин: <span className="text-[var(--text)] font-medium">{currentUser?.email}</span></p>
                <AdminInput label="Новый пароль" value={newPass} onChange={v => setNewPass(v)} type="password" ph="Введите новый пароль" />
                <AdminInput label="Подтвердите пароль" value={confirmPass} onChange={v => setConfirmPass(v)} type="password" ph="Повторите пароль" />
                {passMsg && (
                  <p className={`text-[12px] px-3 py-2 rounded-lg ${passMsg.startsWith('✅') ? 'text-green-400 bg-green-500/10' : 'text-red-400 bg-red-500/10'}`}>{passMsg}</p>
                )}
                <button onClick={handleChangePassword} className="admin-btn bg-[var(--gold)] text-[#0B0B0D]">Сменить пароль</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
