import { useStore } from '../contexts/AppContext';

interface Props { onCatalog: () => void; onCallback: () => void; }

function DropletVisual() {
  return (
    <div className="hero-drop-wrap">
      <svg viewBox="0 0 320 400" fill="none" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <radialGradient id="dg1" cx="0.4" cy="0.35" r="0.65">
            <stop offset="0%" stopColor="#C6A96B" stopOpacity="0.25"/>
            <stop offset="40%" stopColor="#7ABFCC" stopOpacity="0.08"/>
            <stop offset="100%" stopColor="#0B0B0D" stopOpacity="0"/>
          </radialGradient>
          <radialGradient id="dg2" cx="0.35" cy="0.3" r="0.35">
            <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.08"/>
            <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0"/>
          </radialGradient>
          <linearGradient id="dg3" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#C6A96B" stopOpacity="0.12"/>
            <stop offset="100%" stopColor="#7ABFCC" stopOpacity="0.04"/>
          </linearGradient>
          <filter id="glow">
            <feGaussianBlur stdDeviation="20" result="blur"/>
            <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
          </filter>
        </defs>
        <ellipse cx="160" cy="240" rx="140" ry="160" fill="url(#dg1)" filter="url(#glow)" opacity="0.6"/>
        <path d="M160 40 C160 40, 60 160, 60 240 C60 310, 105 370, 160 370 C215 370, 260 310, 260 240 C260 160, 160 40, 160 40Z"
          fill="url(#dg3)" stroke="rgba(198,169,107,0.15)" strokeWidth="1"/>
        <path d="M160 60 C160 60, 80 170, 80 240 C80 300, 115 350, 160 350 C205 350, 240 300, 240 240 C240 170, 160 60, 160 60Z"
          fill="url(#dg2)"/>
        <ellipse cx="140" cy="160" rx="30" ry="18" fill="white" opacity="0.06" transform="rotate(-15 140 160)"/>
        <ellipse cx="135" cy="150" rx="14" ry="8" fill="white" opacity="0.1" transform="rotate(-15 135 150)"/>
        <ellipse cx="160" cy="340" rx="50" ry="15" fill="rgba(198,169,107,0.06)"/>
      </svg>
    </div>
  );
}

export default function Hero({ onCatalog, onCallback }: Props) {
  const { settings, about } = useStore();

  const hasImage = !!settings.heroImage;
  const mode = settings.heroImageMode || 'right';
  const opacity = (settings.heroImageOpacity ?? 100) / 100;
  const scale = (settings.heroImageScale ?? 100) / 100;
  const isBehind = hasImage && mode === 'behind';

  const navItems = [
    { label: 'Каталог', href: '#catalog' },
    { label: 'О нас', href: '#about' },
    { label: 'Линейки', href: '#brands' },
  ];

  return (
    <>
      <section className="relative min-h-[85vh] flex items-center pt-[72px] overflow-hidden">
        {/* Background radials */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse 80% 60% at 70% 40%, rgba(198,169,107,0.04), transparent)' }} />
          <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse 50% 50% at 20% 80%, rgba(122,191,204,0.02), transparent)' }} />
        </div>

        {/* "Behind" mode — image as full background behind text */}
        {isBehind && (
          <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
            {/* Gold glow behind image */}
            <div className="absolute w-[500px] h-[500px] md:w-[700px] md:h-[700px] rounded-full"
              style={{ background: 'radial-gradient(circle, rgba(198,169,107,0.08) 0%, transparent 70%)', filter: 'blur(40px)' }} />
            <img
              src={settings.heroImage}
              alt=""
              className="relative max-h-[70vh] object-contain"
              style={{ opacity: opacity * 0.35, transform: `scale(${scale})`, filter: 'blur(1px)' }}
              onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
            />
          </div>
        )}

        <div className={`max-w-[1200px] mx-auto px-5 lg:px-8 w-full grid ${hasImage && mode === 'right' ? 'md:grid-cols-[1fr,auto]' : ''} gap-12 lg:gap-16 items-center py-12 md:py-0`}>
          {/* Left — text */}
          <div className={`flex flex-col gap-7 ${hasImage && mode === 'right' ? 'order-2 md:order-1' : ''} relative z-10`}>
            <div className="tag w-fit">
              <span className="dot" />
              Премиальная бытовая химия
            </div>

            <div>
              <h1 className="text-[clamp(32px,5.5vw,56px)] font-extrabold leading-[1.08] tracking-[-0.03em] mb-4" style={{ fontFamily: 'Manrope' }}>
                {settings.heroTitle}
              </h1>
              <p className="text-[clamp(14px,1.8vw,16px)] text-[var(--text2)] leading-[1.7] max-w-[480px]">
                {settings.heroSubtitle}
              </p>
            </div>

            <div className="flex gap-3">
              <button onClick={onCatalog} className="btn-gold">
                {settings.heroBtn1}
              </button>
            </div>

            {/* Stats */}
            {about.stats.length > 0 && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 pt-4 border-t border-[var(--border)]">
                {about.stats.map((stat, i) => (
                  <div key={i}>
                    <div className="text-[clamp(22px,3vw,30px)] font-bold tracking-[-0.02em]" style={{ fontFamily: 'Manrope', color: 'var(--gold)' }}>{stat.value}</div>
                    <div className="text-[12px] text-[var(--text3)] mt-1 leading-snug">{stat.label}</div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Right — visual (only in "right" mode or no image) */}
          {(!hasImage || mode === 'right') && (
            <div className={`flex items-center justify-center ${hasImage && mode === 'right' ? 'order-1 md:order-2' : ''}`}>
              {hasImage ? (
                <div className="hero-drop-wrap">
                  <div className="relative w-[280px] h-[340px] sm:w-[320px] sm:h-[400px] flex items-center justify-center">
                    {/* Gold glow */}
                    <div className="absolute inset-0 rounded-[28px]" style={{
                      background: 'radial-gradient(ellipse at center, rgba(198,169,107,0.12) 0%, transparent 70%)',
                      filter: 'blur(30px)', transform: 'scale(1.3)',
                    }} />
                    {/* Border frame */}
                    <div className="absolute inset-[6px] rounded-[24px] border border-[rgba(198,169,107,0.15)]" />
                    <img
                      src={settings.heroImage}
                      alt="Hero"
                      className="relative w-full h-full object-contain rounded-[24px] drop-shadow-2xl"
                      style={{
                        opacity,
                        transform: `scale(${scale})`,
                        filter: 'drop-shadow(0 20px 60px rgba(198,169,107,0.15))',
                      }}
                      onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
                    />
                  </div>
                </div>
              ) : (
                <DropletVisual />
              )}
            </div>
          )}
        </div>
      </section>

      {/* Sub-navigation bar — uses CSS var for theme-aware bg */}
      <nav className="sticky top-[72px] z-40 border-b border-[var(--border)]"
        style={{ background: 'var(--subnav-bg)', backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)' }}>
        <div className="max-w-[1200px] mx-auto px-5 lg:px-8 flex items-center gap-1 h-12 overflow-x-auto no-scrollbar">
          {navItems.map(n => (
            <a key={n.label} href={n.href}
              className="flex-shrink-0 px-4 py-2 text-[13px] font-medium text-[var(--text3)] hover:text-[var(--gold)] transition-colors rounded-[10px] hover:bg-[rgba(128,128,128,0.06)]"
              style={{ fontFamily: 'Manrope' }}>
              {n.label}
            </a>
          ))}
          <div className="w-px h-5 bg-[var(--border)] mx-2 flex-shrink-0" />
          {['Сертификаты', 'Доставка', 'Оптовикам'].map(label => (
            <button key={label} onClick={onCallback}
              className="flex-shrink-0 px-4 py-2 text-[13px] font-medium text-[var(--text3)] hover:text-[var(--gold)] transition-colors rounded-[10px] hover:bg-[rgba(128,128,128,0.06)] bg-transparent border-none cursor-pointer"
              style={{ fontFamily: 'Manrope' }}>
              {label}
            </button>
          ))}
        </div>
      </nav>
    </>
  );
}
