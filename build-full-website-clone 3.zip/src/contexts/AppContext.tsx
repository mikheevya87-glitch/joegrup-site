import { createContext, useContext, useState, useEffect, useCallback, useRef, type ReactNode } from 'react';
import {
  type Product, type Category, type User, type CartItem, type Order, type CallbackReq,
  type BrandLine, type AboutData, type SiteSettings, type TelegramSettings,
  defaultSettings, defaultAbout, defaultCategories, defaultProducts, defaultBrandLines, defaultAdminUser, defaultTelegram,
} from '../data';
import { api } from '../api';

let _uid = 100;
export const uid = () => `id_${++_uid}_${Date.now()}`;

function load<T>(key: string, fallback: T): T {
  try { const d = localStorage.getItem(key); return d ? JSON.parse(d) : fallback; } catch { return fallback; }
}
function save(key: string, val: unknown) { localStorage.setItem(key, JSON.stringify(val)); }

/* ─── Merge defaults for settings that may have new fields ─── */
function mergeSettings(saved: SiteSettings): SiteSettings {
  return {
    ...defaultSettings,
    ...saved,
    telegram: { ...defaultTelegram, ...(saved.telegram || {}) },
  };
}

interface Ctx {
  settings: SiteSettings; updateSettings: (u: Partial<SiteSettings>) => void;
  updateTelegram: (u: Partial<TelegramSettings>) => void;
  about: AboutData; updateAbout: (u: Partial<AboutData>) => void;
  products: Product[]; addProduct: (p: Product) => void; updateProduct: (id: string, u: Partial<Product>) => void;
  deleteProduct: (id: string) => void; toggleProductVis: (id: string) => void;
  categories: Category[]; addCategory: (c: Category) => void; updateCategory: (id: string, u: Partial<Category>) => void;
  deleteCategory: (id: string) => void; toggleCategoryVis: (id: string) => void;
  brandLines: BrandLine[]; addBrandLine: (b: BrandLine) => void; updateBrandLine: (id: string, u: Partial<BrandLine>) => void; deleteBrandLine: (id: string) => void;
  users: User[]; currentUser: User | null; login: (e: string, p: string) => string | null; register: (u: Omit<User, 'id' | 'role'>) => string | null; logout: () => void;
  updateUserPassword: (userId: string, newPassword: string) => void;
  cart: CartItem[]; addToCart: (pid: string) => void; removeFromCart: (pid: string) => void; updateCartQty: (pid: string, q: number) => void; clearCart: () => void; cartTotal: number; cartCount: number;
  orders: Order[]; createOrder: (o: Omit<Order, 'id' | 'date' | 'status'>) => void; updateOrderStatus: (id: string, s: Order['status']) => void; deleteOrder: (id: string) => void;
  callbacks: CallbackReq[]; createCallback: (c: Omit<CallbackReq, 'id' | 'date' | 'status'>) => void; updateCallbackStatus: (id: string, s: CallbackReq['status']) => void; deleteCallback: (id: string) => void;
  toggleTheme: () => void;
  notifyTelegram: (type: 'order' | 'callback' | 'registration' | 'test', data?: any) => Promise<{ ok: boolean; error?: string }>;
  resetAll: () => void;
}

const C = createContext<Ctx | null>(null);
export const useStore = () => { const c = useContext(C); if (!c) throw new Error('No store'); return c; };

export function StoreProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<SiteSettings>(() => mergeSettings(load('st_settings', defaultSettings)));
  const [about, setAbout] = useState<AboutData>(() => load('st_about', defaultAbout));
  const [products, setProducts] = useState<Product[]>(() => load('st_products', defaultProducts));
  const [categories, setCategories] = useState<Category[]>(() => load('st_categories', defaultCategories));
  const [brandLines, setBrandLines] = useState<BrandLine[]>(() => load('st_brands', defaultBrandLines));
  const [users, setUsers] = useState<User[]>(() => {
    const loaded = load<User[]>('st_users', [defaultAdminUser]);
    const hasAdmin = loaded.some(u => u.role === 'admin');
    if (!hasAdmin) return [...loaded, defaultAdminUser];
    return loaded;
  });
  const [currentUser, setCurrentUser] = useState<User | null>(() => load('st_curUser', null));
  const [cart, setCart] = useState<CartItem[]>(() => load('st_cart', []));
  const [orders, setOrders] = useState<Order[]>(() => load('st_orders', []));
  const [callbacks, setCallbacks] = useState<CallbackReq[]>(() => load('st_callbacks', []));

  // ─── Apply theme ───
  useEffect(() => {
    const theme = settings.theme || 'dark';
    document.documentElement.setAttribute('data-theme', theme);
    const metaTheme = document.querySelector('meta[name="theme-color"]');
    if (metaTheme) metaTheme.setAttribute('content', theme === 'dark' ? '#0B0B0D' : '#FAFAF8');
  }, [settings.theme]);

  // ─── Apply section spacing ───
  useEffect(() => {
    const mult = settings.sectionSpacing ?? 1;
    document.documentElement.style.setProperty('--section-gap', `${Math.round(56 * mult)}px`);
    document.documentElement.style.setProperty('--section-gap-md', `${Math.round(80 * mult)}px`);
  }, [settings.sectionSpacing]);

  // ─── Persist to localStorage ───
  useEffect(() => { save('st_settings', settings); }, [settings]);
  useEffect(() => { save('st_about', about); }, [about]);
  useEffect(() => { save('st_products', products); }, [products]);
  useEffect(() => { save('st_categories', categories); }, [categories]);
  useEffect(() => { save('st_brands', brandLines); }, [brandLines]);
  useEffect(() => { save('st_users', users); }, [users]);
  useEffect(() => { save('st_curUser', currentUser); }, [currentUser]);
  useEffect(() => { save('st_cart', cart); }, [cart]);
  useEffect(() => { save('st_orders', orders); }, [orders]);
  useEffect(() => { save('st_callbacks', callbacks); }, [callbacks]);

  // ─── Settings ───
  const updateSettings = useCallback((u: Partial<SiteSettings>) => setSettings(p => ({ ...p, ...u })), []);
  const updateTelegram = useCallback((u: Partial<TelegramSettings>) => {
    setSettings(p => ({ ...p, telegram: { ...p.telegram, ...u } }));
  }, []);
  const updateAbout = useCallback((u: Partial<AboutData>) => setAbout(p => ({ ...p, ...u })), []);

  const toggleTheme = useCallback(() => {
    setSettings(p => ({ ...p, theme: p.theme === 'dark' ? 'light' : 'dark' }));
  }, []);

  // ─── Products ───
  const addProduct = useCallback((p: Product) => setProducts(prev => [...prev, p]), []);
  const updateProduct = useCallback((id: string, u: Partial<Product>) => setProducts(prev => prev.map(p => p.id === id ? { ...p, ...u } : p)), []);
  const deleteProduct = useCallback((id: string) => setProducts(prev => prev.filter(p => p.id !== id)), []);
  const toggleProductVis = useCallback((id: string) => setProducts(prev => prev.map(p => p.id === id ? { ...p, visible: !p.visible } : p)), []);

  // ─── Categories ───
  const addCategory = useCallback((c: Category) => setCategories(prev => [...prev, c]), []);
  const updateCategory = useCallback((id: string, u: Partial<Category>) => setCategories(prev => prev.map(c => c.id === id ? { ...c, ...u } : c)), []);
  const deleteCategory = useCallback((id: string) => { setCategories(prev => prev.filter(c => c.id !== id)); setProducts(prev => prev.filter(p => p.categoryId !== id)); }, []);
  const toggleCategoryVis = useCallback((id: string) => setCategories(prev => prev.map(c => c.id === id ? { ...c, visible: !c.visible } : c)), []);

  // ─── Brand Lines ───
  const addBrandLine = useCallback((b: BrandLine) => setBrandLines(prev => [...prev, b]), []);
  const updateBrandLine = useCallback((id: string, u: Partial<BrandLine>) => setBrandLines(prev => prev.map(b => b.id === id ? { ...b, ...u } : b)), []);
  const deleteBrandLine = useCallback((id: string) => setBrandLines(prev => prev.filter(b => b.id !== id)), []);

  // ─── Auth ───
  const login = useCallback((e: string, p: string): string | null => {
    const u = users.find(u => u.email === e && u.password === p);
    if (u) { setCurrentUser(u); return null; }
    if (e === 'admin' && p === 'admin123') {
      const adminUser = users.find(u => u.role === 'admin');
      if (adminUser) {
        const updated = { ...adminUser, email: 'admin', password: 'admin123' };
        setUsers(prev => prev.map(u => u.role === 'admin' ? updated : u));
        setCurrentUser(updated);
        return null;
      }
      const newAdmin = { ...defaultAdminUser };
      setUsers(prev => [...prev, newAdmin]);
      setCurrentUser(newAdmin);
      return null;
    }
    return 'Неверный логин или пароль';
  }, [users]);

  const register = useCallback((data: Omit<User, 'id' | 'role'>): string | null => {
    if (users.find(u => u.email === data.email)) return 'Этот email уже зарегистрирован';
    const nu: User = { ...data, id: uid(), role: 'user' };
    setUsers(prev => [...prev, nu]);
    setCurrentUser(nu);
    // ── Telegram notification ──
    notifyRef.current?.('registration', {
      name: data.name,
      email: data.email,
      phone: data.phone,
      city: data.city,
      company: data.company,
    });
    return null;
  }, [users]);

  const logout = useCallback(() => { setCurrentUser(null); api.logout(); }, []);

  const updateUserPassword = useCallback((userId: string, newPassword: string) => {
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, password: newPassword } : u));
    setCurrentUser(prev => prev && prev.id === userId ? { ...prev, password: newPassword } : prev);
  }, []);

  // ─── Cart ───
  const addToCart = useCallback((pid: string) => setCart(prev => {
    const ex = prev.find(c => c.productId === pid);
    return ex ? prev.map(c => c.productId === pid ? { ...c, quantity: c.quantity + 1 } : c) : [...prev, { productId: pid, quantity: 1 }];
  }), []);
  const removeFromCart = useCallback((pid: string) => setCart(prev => prev.filter(c => c.productId !== pid)), []);
  const updateCartQty = useCallback((pid: string, q: number) => setCart(prev => q <= 0 ? prev.filter(c => c.productId !== pid) : prev.map(c => c.productId === pid ? { ...c, quantity: q } : c)), []);
  const clearCart = useCallback(() => setCart([]), []);
  const cartTotal = cart.reduce((s, ci) => { const p = products.find(p => p.id === ci.productId); return s + (p ? p.price * ci.quantity : 0); }, 0);
  const cartCount = cart.reduce((s, ci) => s + ci.quantity, 0);

  // ─── Orders ───
  const createOrder = useCallback((o: Omit<Order, 'id' | 'date' | 'status'>) => {
    const no: Order = { ...o, id: uid(), date: new Date().toISOString(), status: 'new' };
    setOrders(prev => [no, ...prev]);
    api.createLead({ type: 'order', name: o.customerName, phone: o.phone, email: '', message: `${o.company} | ${o.city} ${o.address}`, itemsJson: JSON.stringify(o.items), total: o.total });
    // ── Telegram notification ──
    notifyRef.current?.('order', {
      name: o.customerName,
      company: o.company,
      phone: o.phone,
      city: o.city,
      address: o.address,
      items: o.items,
      total: o.total,
    });
  }, []);
  const updateOrderStatus = useCallback((id: string, s: Order['status']) => setOrders(prev => prev.map(o => o.id === id ? { ...o, status: s } : o)), []);
  const deleteOrder = useCallback((id: string) => setOrders(prev => prev.filter(o => o.id !== id)), []);

  // ─── Callbacks ───
  const createCallback = useCallback((c: Omit<CallbackReq, 'id' | 'date' | 'status'>) => {
    const nc: CallbackReq = { ...c, id: uid(), date: new Date().toISOString(), status: 'new' };
    setCallbacks(prev => [nc, ...prev]);
    api.createLead({ type: 'callback', name: c.name, phone: c.phone, message: c.comment });
    // ── Telegram notification ──
    notifyRef.current?.('callback', {
      name: c.name,
      phone: c.phone,
      comment: c.comment,
    });
  }, []);
  const updateCallbackStatus = useCallback((id: string, s: CallbackReq['status']) => setCallbacks(prev => prev.map(c => c.id === id ? { ...c, status: s } : c)), []);
  const deleteCallback = useCallback((id: string) => setCallbacks(prev => prev.filter(c => c.id !== id)), []);

  // ─── Telegram notify ref (avoids stale closures in createOrder/createCallback/register) ───
  const notifyRef = useRef<((type: 'order' | 'callback' | 'registration' | 'test', data?: any) => Promise<{ ok: boolean; error?: string }>) | null>(null);

  // ─── Telegram notifications ───
  const notifyTelegram = useCallback(async (type: 'order' | 'callback' | 'registration' | 'test', data?: any): Promise<{ ok: boolean; error?: string }> => {
    const tg = settings.telegram;
    if (!tg.enabled && type !== 'test') return { ok: false, error: 'Уведомления отключены' };
    if (!tg.chatId) return { ok: false, error: 'Не указан Chat ID' };

    // Check specific flags
    if (type === 'callback' && !tg.notifyCallback) return { ok: false, error: 'Уведомления о заявках отключены' };
    if (type === 'order' && !tg.notifyOrder) return { ok: false, error: 'Уведомления о заказах отключены' };
    if (type === 'registration' && !tg.notifyRegistration) return { ok: false, error: 'Уведомления о регистрациях отключены' };

    // Format message
    const icons: Record<string, string> = { test: '🔔', callback: '📞', order: '📦', registration: '👤' };
    const titles: Record<string, string> = { test: 'Тестовое сообщение', callback: 'Новая заявка на звонок', order: 'Новый заказ', registration: 'Новая регистрация' };
    let text = `${icons[type]} <b>${titles[type]}</b>\n\n`;
    if (type === 'test') {
      text += `✅ Уведомления работают!\n🕐 ${new Date().toLocaleString('ru')}`;
    } else if (data) {
      if (data.name) text += `👤 <b>${data.name}</b>\n`;
      if (data.company) text += `🏢 ${data.company}\n`;
      if (data.phone) text += `📞 ${data.phone}\n`;
      if (data.email) text += `📧 ${data.email}\n`;
      if (data.city) text += `📍 ${data.city}`;
      if (data.address) text += `, ${data.address}`;
      if (data.city || data.address) text += '\n';
      if (data.comment) text += `💬 ${data.comment}\n`;
      if (data.items && data.total) {
        text += `\n🛒 <b>Состав заказа:</b>\n`;
        data.items.forEach((it: any) => { text += `  • ${it.productName} × ${it.quantity} = ${it.price * it.quantity} ₽\n`; });
        text += `\n💰 <b>Итого: ${data.total} ₽</b>`;
      }
    }

    console.log(`[Telegram] notify attempt: type=${type}`);

    // Try backend first
    try {
      const backendResult = await api.testTelegram();
      if (backendResult) { console.log('[Telegram] notify success via backend'); return { ok: true }; }
    } catch { /* backend not available */ }

    // Fallback: direct Telegram API (for testing — token in localStorage)
    if (!tg.botToken) return { ok: false, error: 'Бэкенд недоступен и не указан Bot Token для прямой отправки' };

    try {
      const res = await fetch(`https://api.telegram.org/bot${tg.botToken}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: tg.chatId, text, parse_mode: 'HTML' }),
      });
      const json = await res.json();
      if (json.ok) {
        console.log('[Telegram] notify success via direct API');
        return { ok: true };
      } else {
        console.error('[Telegram] notify fail:', json.description);
        return { ok: false, error: json.description || 'Ошибка Telegram API' };
      }
    } catch (err: any) {
      console.error('[Telegram] notify fail:', err);
      return { ok: false, error: err.message || 'Сетевая ошибка' };
    }
  }, [settings.telegram]);

  // ─── Keep notifyRef in sync ───
  useEffect(() => { notifyRef.current = notifyTelegram; }, [notifyTelegram]);

  // ─── Reset ───
  const resetAll = useCallback(() => {
    setSettings(defaultSettings); setAbout(defaultAbout); setProducts(defaultProducts);
    setCategories(defaultCategories); setBrandLines(defaultBrandLines);
    setUsers([defaultAdminUser]); setCurrentUser(null); setCart([]); setOrders([]); setCallbacks([]);
    localStorage.clear();
  }, []);

  return (
    <C.Provider value={{
      settings, updateSettings, updateTelegram, about, updateAbout,
      products, addProduct, updateProduct, deleteProduct, toggleProductVis,
      categories, addCategory, updateCategory, deleteCategory, toggleCategoryVis,
      brandLines, addBrandLine, updateBrandLine, deleteBrandLine,
      users, currentUser, login, register, logout, updateUserPassword,
      cart, addToCart, removeFromCart, updateCartQty, clearCart, cartTotal, cartCount,
      orders, createOrder, updateOrderStatus, deleteOrder,
      callbacks, createCallback, updateCallbackStatus, deleteCallback,
      toggleTheme, notifyTelegram, resetAll,
    }}>
      {children}
    </C.Provider>
  );
}
