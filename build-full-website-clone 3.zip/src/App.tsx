import { useState, useEffect, useCallback } from 'react';
import { StoreProvider, useStore } from './contexts/AppContext';
import Header from './components/Header';
import Hero from './components/Hero';
import Catalog from './components/Catalog';
import About from './components/About';
import BrandLines from './components/BrandLines';
import Footer from './components/Footer';
import LoginModal from './components/LoginModal';
import AdminPanel from './components/AdminPanel';

/* ═══════════════════════════════════════════
   FLOATING DROPLETS — decorative background
   ═══════════════════════════════════════════ */
function FloatingDroplets() {
  const drops = [
    { w: 160, h: 200, top: '8%', left: '4%', opacity: 0.04, anim: 'float-a 40s ease-in-out infinite', color: 'gold' },
    { w: 100, h: 130, top: '45%', right: '6%', opacity: 0.03, anim: 'float-b 35s ease-in-out infinite 8s', color: 'ice' },
    { w: 80, h: 100, top: '72%', left: '12%', opacity: 0.035, anim: 'float-c 45s ease-in-out infinite 3s', color: 'gold' },
    { w: 120, h: 150, top: '22%', right: '18%', opacity: 0.025, anim: 'float-a 50s ease-in-out infinite 15s', color: 'ice' },
    { w: 60, h: 80, top: '88%', left: '55%', opacity: 0.04, anim: 'float-b 38s ease-in-out infinite 6s', color: 'gold' },
  ];

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      {drops.map((d, i) => (
        <div key={i} className="droplet" style={{ width: d.w, height: d.h, top: d.top, left: d.left, right: d.right, opacity: d.opacity, animation: d.anim } as React.CSSProperties}>
          <svg viewBox="0 0 100 130" fill="none">
            <defs>
              <radialGradient id={`dg-${i}`} cx="0.4" cy="0.35" r="0.6">
                <stop offset="0%" stopColor={d.color === 'gold' ? '#C6A96B' : '#7ABFCC'} stopOpacity="0.4" />
                <stop offset="100%" stopColor={d.color === 'gold' ? '#C6A96B' : '#7ABFCC'} stopOpacity="0" />
              </radialGradient>
            </defs>
            <path d="M50 5 C50 5, 10 50, 10 75 C10 100, 28 125, 50 125 C72 125, 90 100, 90 75 C90 50, 50 5, 50 5Z" fill={`url(#dg-${i})`} />
          </svg>
        </div>
      ))}
    </div>
  );
}

/* ═══════════════════════════════════════════
   CALLBACK MODAL — "Заказать звонок"
   ═══════════════════════════════════════════ */
function CallbackModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { createCallback } = useStore();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [comment, setComment] = useState('');
  const [sent, setSent] = useState(false);

  if (!open) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone) return;
    createCallback({ name, phone, comment });
    setSent(true);
    setTimeout(() => { setSent(false); onClose(); setName(''); setPhone(''); setComment(''); }, 2500);
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/75 backdrop-blur-md" />
      <div className="relative w-full max-w-[420px] bg-[var(--surface)] rounded-[var(--radius-l)] border border-[var(--border)] shadow-2xl overflow-hidden" onClick={e => e.stopPropagation()}>
        <div className="p-7">
          {sent ? (
            <div className="text-center py-10">
              <div className="w-16 h-16 rounded-full mx-auto mb-5 flex items-center justify-center" style={{ background: 'rgba(34,197,94,0.1)', border: '1px solid rgba(34,197,94,0.2)' }}>
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#22C55E" strokeWidth="2"><polyline points="20 6 9 17 4 12"/></svg>
              </div>
              <h3 className="text-[20px] font-bold mb-2" style={{ fontFamily: 'Manrope' }}>Заявка отправлена!</h3>
              <p className="text-[13px] text-[var(--text3)]">Мы перезвоним вам в ближайшее время</p>
            </div>
          ) : (
            <>
              <p className="section-label">Обратная связь</p>
              <h3 className="text-[20px] font-bold mb-1" style={{ fontFamily: 'Manrope' }}>Заказать звонок</h3>
              <p className="text-[13px] text-[var(--text3)] mb-6">Оставьте заявку — мы перезвоним</p>
              <form onSubmit={handleSubmit} className="flex flex-col gap-3.5">
                <input className="admin-input" placeholder="Ваше имя *" value={name} onChange={e => setName(e.target.value)} required />
                <input className="admin-input" placeholder="Телефон *" value={phone} onChange={e => setPhone(e.target.value)} required />
                <textarea className="admin-input" placeholder="Комментарий (необязательно)" rows={3} value={comment} onChange={e => setComment(e.target.value)} style={{ resize: 'none' }} />
                <button type="submit" className="btn-gold w-full py-3.5 mt-1">Жду звонка!</button>
              </form>
            </>
          )}
        </div>
        <button onClick={onClose} className="absolute top-3.5 right-3.5 w-8 h-8 rounded-[10px] flex items-center justify-center text-[var(--text3)] hover:text-[var(--text)] hover:bg-[rgba(255,255,255,0.04)] bg-transparent border-none cursor-pointer transition-colors">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════
   CART MODAL
   ═══════════════════════════════════════════ */
function CartModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { cart, products, removeFromCart, updateCartQty, clearCart, cartTotal, createOrder, currentUser } = useStore();
  const [step, setStep] = useState<'cart' | 'order' | 'done'>('cart');
  const [formName, setFormName] = useState('');
  const [formCompany, setFormCompany] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formCity, setFormCity] = useState('');
  const [formAddress, setFormAddress] = useState('');

  useEffect(() => {
    if (open && currentUser) {
      setFormName(currentUser.name);
      setFormCompany(currentUser.company);
      setFormPhone(currentUser.phone);
      setFormCity(currentUser.city);
      setFormAddress(currentUser.address);
    }
  }, [open, currentUser]);

  if (!open) return null;

  const cartItems = cart.map(ci => {
    const p = products.find(pr => pr.id === ci.productId);
    return p ? { ...ci, product: p } : null;
  }).filter(Boolean) as { productId: string; quantity: number; product: typeof products[0] }[];

  const handleOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName || !formPhone) return;
    createOrder({
      userId: currentUser?.id,
      customerName: formName, company: formCompany, phone: formPhone, city: formCity, address: formAddress,
      items: cartItems.map(ci => ({ productId: ci.productId, quantity: ci.quantity, productName: ci.product.name, price: ci.product.price })),
      total: cartTotal,
    });
    clearCart();
    setStep('done');
    setTimeout(() => { setStep('cart'); onClose(); }, 3000);
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/75 backdrop-blur-md" />
      <div className="relative w-full max-w-[480px] bg-[var(--surface)] rounded-[var(--radius-l)] border border-[var(--border)] shadow-2xl max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="p-7">
          {step === 'done' ? (
            <div className="text-center py-10">
              <div className="w-16 h-16 rounded-full mx-auto mb-5 flex items-center justify-center" style={{ background: 'rgba(198,169,107,0.1)', border: '1px solid rgba(198,169,107,0.2)' }}>
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="var(--gold)" strokeWidth="2"><polyline points="20 6 9 17 4 12"/></svg>
              </div>
              <h3 className="text-[20px] font-bold mb-2" style={{ fontFamily: 'Manrope' }}>Заказ оформлен!</h3>
              <p className="text-[13px] text-[var(--text3)]">Мы свяжемся с вами для подтверждения</p>
            </div>
          ) : step === 'order' ? (
            <>
              <p className="section-label">Оформление</p>
              <h3 className="text-[20px] font-bold mb-5" style={{ fontFamily: 'Manrope' }}>Данные для заказа</h3>
              <form onSubmit={handleOrder} className="flex flex-col gap-3">
                <input className="admin-input" placeholder="Имя / Компания *" value={formName} onChange={e => setFormName(e.target.value)} required />
                <input className="admin-input" placeholder="Компания" value={formCompany} onChange={e => setFormCompany(e.target.value)} />
                <input className="admin-input" placeholder="Телефон *" value={formPhone} onChange={e => setFormPhone(e.target.value)} required />
                <div className="grid grid-cols-2 gap-3">
                  <input className="admin-input" placeholder="Город" value={formCity} onChange={e => setFormCity(e.target.value)} />
                  <input className="admin-input" placeholder="Адрес" value={formAddress} onChange={e => setFormAddress(e.target.value)} />
                </div>
                {/* Order summary */}
                <div className="bg-[var(--bg)] rounded-[var(--radius)] p-4 mt-2 border border-[var(--border)]">
                  {cartItems.map(ci => (
                    <div key={ci.productId} className="flex justify-between text-[12px] py-1.5 text-[var(--text2)]">
                      <span className="truncate max-w-[200px]">{ci.product.name} × {ci.quantity}</span>
                      <span className="text-[var(--gold)] font-medium">{ci.product.price * ci.quantity} ₽</span>
                    </div>
                  ))}
                  <div className="border-t border-[var(--border)] mt-2 pt-2 flex justify-between font-bold text-[14px]" style={{ fontFamily: 'Manrope' }}>
                    <span>Итого</span><span className="text-[var(--gold)]">{cartTotal} ₽</span>
                  </div>
                </div>
                <div className="flex gap-3 mt-3">
                  <button type="button" onClick={() => setStep('cart')} className="btn-outline flex-1 py-3 btn-sm">Назад</button>
                  <button type="submit" className="btn-gold flex-1 py-3 btn-sm">Подтвердить</button>
                </div>
              </form>
            </>
          ) : (
            <>
              <p className="section-label">Покупки</p>
              <h3 className="text-[20px] font-bold mb-5" style={{ fontFamily: 'Manrope' }}>Корзина</h3>
              {cartItems.length === 0 ? (
                <div className="text-center py-12">
                  <div className="text-[36px] mb-4 opacity-10">🛒</div>
                  <p className="text-[13px] text-[var(--text3)]">Корзина пуста</p>
                </div>
              ) : (
                <>
                  <div className="flex flex-col gap-2.5">
                    {cartItems.map(ci => (
                      <div key={ci.productId} className="flex items-center gap-3 bg-[var(--bg)] rounded-[var(--radius)] p-3 border border-[var(--border)]">
                        <div className="w-11 h-11 rounded-[10px] bg-[var(--surface2)] flex items-center justify-center flex-shrink-0 overflow-hidden">
                          {ci.product.image ? <img src={ci.product.image} alt="" className="w-full h-full object-cover" /> : <span className="text-[16px] opacity-30">📦</span>}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-[13px] font-medium truncate">{ci.product.name}</p>
                          <p className="text-[12px] text-[var(--gold)]">{ci.product.price} ₽</p>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <button onClick={() => updateCartQty(ci.productId, ci.quantity - 1)}
                            className="w-7 h-7 rounded-[8px] bg-[var(--surface)] border border-[var(--border)] text-[12px] text-[var(--text)] cursor-pointer flex items-center justify-center hover:border-[var(--border3)] transition-colors">−</button>
                          <span className="text-[13px] w-6 text-center font-medium">{ci.quantity}</span>
                          <button onClick={() => updateCartQty(ci.productId, ci.quantity + 1)}
                            className="w-7 h-7 rounded-[8px] bg-[var(--surface)] border border-[var(--border)] text-[12px] text-[var(--text)] cursor-pointer flex items-center justify-center hover:border-[var(--border3)] transition-colors">+</button>
                        </div>
                        <button onClick={() => removeFromCart(ci.productId)}
                          className="text-[var(--text3)] hover:text-red-400 bg-transparent border-none cursor-pointer transition-colors p-1">
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                        </button>
                      </div>
                    ))}
                  </div>
                  <div className="border-t border-[var(--border)] mt-5 pt-5 flex justify-between items-center">
                    <span className="text-[18px] font-bold" style={{ fontFamily: 'Manrope' }}>Итого: <span className="text-[var(--gold)]">{cartTotal} ₽</span></span>
                  </div>
                  <div className="flex gap-3 mt-5">
                    <button onClick={clearCart} className="btn-outline flex-1 py-3 btn-sm">Очистить</button>
                    <button onClick={() => setStep('order')} className="btn-gold flex-1 py-3 btn-sm">Оформить</button>
                  </div>
                </>
              )}
            </>
          )}
        </div>
        <button onClick={onClose} className="absolute top-3.5 right-3.5 w-8 h-8 rounded-[10px] flex items-center justify-center text-[var(--text3)] hover:text-[var(--text)] hover:bg-[rgba(255,255,255,0.04)] bg-transparent border-none cursor-pointer transition-colors">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════
   MAIN APP
   ═══════════════════════════════════════════ */
function AppInner() {
  const { currentUser, callbacks } = useStore();
  const [loginOpen, setLoginOpen] = useState(false);
  const [callbackOpen, setCallbackOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);
  const [activeCat, setActiveCat] = useState<string | null>(null);
  const [showTop, setShowTop] = useState(false);

  const isAdmin = currentUser?.role === 'admin';
  const newCb = callbacks.filter(c => c.status === 'new').length;

  useEffect(() => {
    const h = () => setShowTop(window.scrollY > 500);
    window.addEventListener('scroll', h, { passive: true });
    return () => window.removeEventListener('scroll', h);
  }, []);

  // Scroll reveal observer
  const initObserver = useCallback(() => {
    const obs = new IntersectionObserver((entries) => {
      entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); obs.unobserve(e.target); } });
    }, { threshold: 0.08, rootMargin: '0px 0px -40px 0px' });
    document.querySelectorAll('.sr').forEach(el => obs.observe(el));
    return () => obs.disconnect();
  }, []);

  useEffect(() => {
    const cleanup = initObserver();
    return cleanup;
  });

  const scrollToCatalog = (catId?: string) => {
    if (catId) setActiveCat(catId);
    document.getElementById('catalog')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="grain relative min-h-screen" style={{ fontFamily: "'Inter', sans-serif" }}>
      <FloatingDroplets />

      <div className="relative z-10">
        <Header onLogin={() => setLoginOpen(true)} onCart={() => setCartOpen(true)} onCallback={() => setCallbackOpen(true)} />
        <Hero onCatalog={() => scrollToCatalog()} onCallback={() => setCallbackOpen(true)} />
        <div className="sr"><Catalog activeCat={activeCat} /></div>
        <div className="sr"><About onCallback={() => setCallbackOpen(true)} /></div>
        <div className="sr"><BrandLines /></div>
        <Footer onCallback={() => setCallbackOpen(true)} />
      </div>

      {/* Modals */}
      <LoginModal open={loginOpen} onClose={() => setLoginOpen(false)} />
      <CallbackModal open={callbackOpen} onClose={() => setCallbackOpen(false)} />
      <CartModal open={cartOpen} onClose={() => setCartOpen(false)} />
      <AdminPanel open={adminOpen} onClose={() => setAdminOpen(false)} />

      {/* Admin FAB */}
      {isAdmin && (
        <button onClick={() => setAdminOpen(true)}
          className="fixed bottom-20 right-5 z-[100] w-12 h-12 rounded-[var(--radius)] flex items-center justify-center shadow-lg cursor-pointer border-none"
          style={{ background: 'linear-gradient(135deg, var(--gold), var(--gold-l))', color: '#0B0B0D' }}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 01-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/>
          </svg>
          {newCb > 0 && (
            <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] rounded-full bg-red-500 text-white text-[10px] flex items-center justify-center font-bold px-1">{newCb}</span>
          )}
        </button>
      )}

      {/* Mobile callback FAB */}
      <button onClick={() => setCallbackOpen(true)}
        className="sm:hidden fixed bottom-5 right-5 z-[100] w-12 h-12 rounded-[var(--radius)] flex items-center justify-center shadow-lg border border-[var(--border)] cursor-pointer bg-[var(--surface)] text-[var(--gold)]"
        style={{ backdropFilter: 'blur(12px)' }}>
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
          <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/>
        </svg>
      </button>

      {/* Scroll to top */}
      <button
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        className={`fixed bottom-5 left-5 z-[100] w-10 h-10 rounded-[var(--radius-s)] flex items-center justify-center bg-[var(--surface)] border border-[var(--border)] text-[var(--text3)] hover:text-[var(--gold)] hover:border-[var(--gold-b)] cursor-pointer shadow-lg transition-all duration-300 ${
          showTop ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'
        }`}>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="18 15 12 9 6 15"/></svg>
      </button>
    </div>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <AppInner />
    </StoreProvider>
  );
}
