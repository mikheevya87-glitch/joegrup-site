import path from "path";
import { fileURLToPath } from "url";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "src"),
    },
  },
  build: {
    // Стандартная сборка: index.html + assets/ (JS, CSS отдельно)
    // Это позволяет браузеру кэшировать ассеты и загружать параллельно
    outDir: "dist",
    assetsDir: "assets",
    sourcemap: false,
    // Размер warning — 500KB
    chunkSizeWarningLimit: 500,
  },
});
